using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.DependencyInjection;
using CommunityToolkit.Mvvm.Input;
using NewToys.Shared.Models;
using NewToys.Shared.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace NewToys.Shell.ViewModels;

public partial class ShellViewModel : ViewModelBase
{
    private readonly IMenuService _menuService;
    private readonly INavigationService? _nav;
    private bool _isSyncing = false;

    [ObservableProperty]
    private bool _isHomePage = true;

    [ObservableProperty]
    private MenuGroup? _selectedGroup;

    [ObservableProperty]
    private MenuItem? _selectedItem;

    public ObservableCollection<MenuGroup> Groups => _menuService.Groups;

    public ShellViewModel() : this(
        Ioc.Default.GetService<IMenuService>()!,
        Ioc.Default.GetService<INavigationService>())
    { }

    public ShellViewModel(IMenuService menuService, INavigationService? nav)
    {
        _menuService = menuService ?? throw new ArgumentNullException(nameof(menuService));
        _nav = nav;
    }

    [RelayCommand]
    public void GoHome()
    {
        _isSyncing = true;
        try
        {
            IsHomePage = true;
            SelectedGroup = null;
            SelectedItem = null;
        }
        finally { _isSyncing = false; }
    }

    /// <summary>点击侧栏分组按钮时切换到该分组的第一个页面。</summary>
    [RelayCommand]
    public void SelectGroup(MenuGroup? group)
    {
        if (group == null) return;
        var first = group.Items?.FirstOrDefault();
        if (first != null) NavigateToPage(first.Key);
        else NavigateToPage(group.Key);
    }

    /// <summary>底部侧栏 ⚙ 按钮：进入"通用设置"页。</summary>
    [RelayCommand]
    public void GoSettings() => NavigateToPage("settings-general");

    /// <summary>
    /// 按页面 Key 一次性切换到对应模块页面。
    /// 同时同步左侧侧栏高亮、二级菜单选中态与内容区视图。
    /// </summary>
    public void NavigateToPage(string key)
    {
        if (string.IsNullOrEmpty(key)) return;

        if (key == "home")
        {
            GoHome();
            _nav?.NavigateTo("home");
            return;
        }

        MenuGroup? targetGroup = null;
        MenuItem? targetItem = null;
        foreach (var g in _menuService.Groups)
        {
            if (g.Key == key)
            {
                targetGroup = g;
                targetItem = g.Items?.FirstOrDefault();
                break;
            }
            var it = g.Items?.FirstOrDefault(i => i.Key == key);
            if (it != null)
            {
                targetGroup = g;
                targetItem = it;
                break;
            }
        }

        if (targetGroup == null || targetItem == null)
        {
            _nav?.NavigateTo(key);
            return;
        }

        // ⚠️ 关键：赋值顺序必须是 SelectedGroup → SelectedItem → IsHomePage。
        // UI 监听 IsHomePage 变化会立即触发 ShowPageMode() → RebuildSubMenu()，
        // 如果此时 SelectedGroup 还没跟上，RebuildSubMenu 会因 SelectedGroup==null
        // 直接把 SubPanel 隐藏，导致二级菜单面板永远不出现。
        _isSyncing = true;
        try
        {
            SelectedGroup = targetGroup;
            SelectedItem = targetItem;
            IsHomePage = false;
        }
        finally
        {
            _isSyncing = false;
        }

        // 退出 _isSyncing 后再显式导航到目标页：让 NavigationService 构造真实视图，
        // 同时触发 code-behind 的 RebuildSubMenu 在 SelectedGroup 已就绪的状态下运行。
        try
        {
            _nav?.NavigateTo(targetItem.Key);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"导航失败: {ex.Message}");
        }
    }

    partial void OnSelectedGroupChanged(MenuGroup? value)
    {
        if (_isSyncing || value == null) return;
        _isSyncing = true;
        try
        {
            IsHomePage = false;
            var first = value.Items?.FirstOrDefault();
            if (first != null)
            {
                SelectedItem = first;
                _nav?.NavigateTo(first.Key);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"切分组失败: {ex.Message}");
        }
        finally { _isSyncing = false; }
    }

    partial void OnSelectedItemChanged(MenuItem? value)
    {
        if (_isSyncing || value == null) return;
        try
        {
            _nav?.NavigateTo(value.Key);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"导航失败: {ex.Message}");
        }
    }
}
