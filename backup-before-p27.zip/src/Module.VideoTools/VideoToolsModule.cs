using Microsoft.Extensions.DependencyInjection;
using NewToys.Module.VideoTools.ViewModels;
using NewToys.Shared.Models;
using NewToys.Shared.Services;

namespace NewToys.Module.VideoTools;

public class VideoToolsModule : IModule
{
    public void RegisterServices(IServiceCollection services)
    {
        services.AddTransient<VideoListViewModel>();
        services.AddTransient<VideoCutViewModel>();
        services.AddTransient<TranscodeViewModel>();
    }

    public void Initialize(IServiceProvider services)
    {
        var menu = services.GetRequiredService<IMenuService>();
        var group = menu.AddGroup("video", "视频工具箱", "🎬", order: 30);
        menu.AddItem("video", new MenuItem { Key = "video-list", Title = "视频库", ViewModelType = typeof(VideoListViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("video", new MenuItem { Key = "video-cut", Title = "视频剪辑", ViewModelType = typeof(VideoCutViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("video", new MenuItem { Key = "video-transcode", Title = "格式转码", ViewModelType = typeof(TranscodeViewModel).AssemblyQualifiedName ?? "" });
    }
}
