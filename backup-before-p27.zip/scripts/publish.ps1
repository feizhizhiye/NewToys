param(
    [string]$Version = "v0.1.11",
    [ValidateSet("win-x64", "linux-x64", "osx-x64")]
    [string]$Runtime = "win-x64",
    [switch]$Standalone,
    [switch]$Trim
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptDir
$SrcDir = Join-Path $RepoRoot "src"
$PublishRoot = Join-Path $RepoRoot "production\NewToys_$Version`_$Runtime"
$ModulesDir = Join-Path $PublishRoot "Modules"

Write-Host "==> 发布 NewToys $Version ($Runtime)" -ForegroundColor Cyan
Write-Host "==> 输出目录: $PublishRoot" -ForegroundColor Gray

if (-not (Test-Path $PublishRoot)) {
    New-Item -ItemType Directory -Path $PublishRoot -Force | Out-Null
}
if (-not (Test-Path $ModulesDir)) {
    New-Item -ItemType Directory -Path $ModulesDir -Force | Out-Null
}

Push-Location $SrcDir
try {
    $publishArgs = @(
        "publish", "Shell/Shell.csproj",
        "-c", "Release",
        "-r", $Runtime,
        "-o", $PublishRoot,
        "--self-contained", $(if ($Standalone) { "true" } else { "false" })
    )
    if ($Trim) { $publishArgs += "/p:PublishTrimmed=true" }

    Write-Host "`n==> 发布Shell..." -ForegroundColor Cyan
    dotnet @publishArgs
    if ($LASTEXITCODE -ne 0) { throw "发布Shell失败" }

    # 发布所有模块并复制到Modules
    Write-Host "`n==> 发布所有模块..." -ForegroundColor Cyan
    Get-ChildItem $SrcDir -Directory -Filter "Module.*" | ForEach-Object {
        $moduleName = $_.Name
        $moduleOutDir = Join-Path $RepoRoot "artifacts\publish\$moduleName"
        Write-Host "  发布 $moduleName..." -ForegroundColor Gray

        dotnet publish "$($_.FullName)\$moduleName.csproj" -c Release -r $Runtime -o $moduleOutDir --no-self-contained
        if ($LASTEXITCODE -ne 0) { throw "发布模块 $moduleName 失败" }

        # 复制模块DLL到发布目录的Modules
        Get-ChildItem $moduleOutDir -Filter "NewToys.$moduleName.dll" | ForEach-Object {
            Copy-Item $_.FullName -Destination $ModulesDir -Force
        }
    }

    # 复制Shared/Core
    @("Shared", "Core") | ForEach-Object {
        $dll = Join-Path $PublishRoot "NewToys.$_.dll"
        if (Test-Path $dll) {
            Copy-Item $dll -Destination $ModulesDir -Force
        }
    }
}
finally {
    Pop-Location
}

# 创建var目录
@("config", "logs", "cache", "temp") | ForEach-Object {
    $path = Join-Path $PublishRoot "var\$_"
    if (-not (Test-Path $path)) { New-Item -ItemType Directory -Path $path -Force | Out-Null }
}

Write-Host "`n✅ 发布完成! 路径: $PublishRoot" -ForegroundColor Green
