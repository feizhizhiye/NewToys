using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Shared.Models;

public class ViewModelBase : ObservableObject
{
}
