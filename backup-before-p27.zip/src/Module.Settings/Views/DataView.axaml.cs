using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using NewToys.Module.Settings.ViewModels;
using System;
using System.Linq;

namespace NewToys.Module.Settings.Views;

public partial class DataView : UserControl
{
    public DataView()
    {
        InitializeComponent();
    }

    private static IBrush? GetBrush(string key)
    {
        if (Application.Current?.TryFindResource(key, out var res) == true && res is IBrush b)
            return b;
        return null;
    }

    private async void BtnBackup_Click(object? sender, RoutedEventArgs e)
    {
        try
        {
            if (DataContext is not DataViewModel vm) return;
            var topLevel = TopLevel.GetTopLevel(this);
            if (topLevel == null) return;

            var file = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "备份 NewToys 配置",
                SuggestedFileName = $"newtoys-config-{DateTime.Now:yyyyMMdd-HHmmss}.json",
                DefaultExtension = "json",
                FileTypeChoices = new[]
                {
                    new FilePickerFileType("NewToys 配置备份") { Patterns = new[] { "*.json" } },
                    FilePickerFileTypes.All,
                },
            });
            if (file == null) return;

            var json = vm.BuildBackupText();
            await using var stream = await file.OpenWriteAsync();
            using var writer = new System.IO.StreamWriter(stream);
            await writer.WriteAsync(json);

            vm.MarkBackupSaved(file.Path.LocalPath);
            ShowDialog("备份成功", $"配置已备份到：\n{file.Path.LocalPath}");
        }
        catch (Exception ex)
        {
            ShowDialog("备份失败", ex.Message);
        }
    }

    private async void BtnImport_Click(object? sender, RoutedEventArgs e)
    {
        try
        {
            if (DataContext is not DataViewModel vm) return;
            var topLevel = TopLevel.GetTopLevel(this);
            if (topLevel == null) return;

            var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "选择 NewToys 配置备份文件",
                AllowMultiple = false,
                FileTypeFilter = new[]
                {
                    new FilePickerFileType("NewToys 配置备份") { Patterns = new[] { "*.json" } },
                    FilePickerFileTypes.All,
                },
            });
            var pick = files.FirstOrDefault();
            if (pick == null) return;

            var peek = vm.PeekBackupFile(pick.Path.LocalPath);
            if (!peek.Ok)
            {
                ShowDialog("备份文件无效", peek.Error);
                return;
            }

            var confirm = await ShowConfirmDialog("确认导入",
                $"即将导入以下 {peek.Files.Length} 个配置文件：\n  {string.Join("\n  ", peek.Files)}\n\n导入前会自动备份当前配置到 .bak 目录。是否继续？");
            if (!confirm) return;

            var r = vm.ImportBackupFile(pick.Path.LocalPath);
            if (r.Ok)
                ShowDialog("导入成功", $"已导入 {r.Imported.Length} 个配置文件。\n旧配置已自动备份到：\n{r.AutoBackupDir}\n\n建议重启 NewToys 以让全部配置生效。");
            else
                ShowDialog("导入失败", r.Error);
        }
        catch (Exception ex)
        {
            ShowDialog("导入失败", ex.Message);
        }
    }

    private void BtnRefresh_Click(object? sender, RoutedEventArgs e)
    {
        if (DataContext is DataViewModel vm) vm.RefreshCommand.Execute(null);
    }

    // -------- 简单内置对话框（不引入第三方 MessageBox 包） --------
    private Window CreateDialog(string title, string message, string okText = "确定", string? cancelText = null)
    {
        var win = new Window
        {
            Title = title,
            Width = 480,
            Height = 280,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            CanResize = false,
            Background = GetBrush("AppBackground"),
        };
        var panel = new DockPanel { Margin = new Thickness(24) };

        var btnBar = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right,
            Spacing = 8,
        };
        var okBtn = new Button
        {
            Content = okText,
            Height = 32,
            Padding = new Thickness(16, 0),
            Background = GetBrush("AccentColor") ?? new SolidColorBrush(Color.Parse("#07C160")),
            Foreground = GetBrush("AccentText") ?? Brushes.White,
            CornerRadius = new CornerRadius(6),
            Tag = true,
        };
        var cancelBtn = new Button
        {
            Content = cancelText ?? "取消",
            Height = 32,
            Padding = new Thickness(16, 0),
            Background = GetBrush("CardBackground") ?? new SolidColorBrush(Color.Parse("#F7F8FA")),
            Foreground = GetBrush("TextPrimary") ?? Brushes.Black,
            BorderBrush = GetBrush("BorderColor") ?? new SolidColorBrush(Color.Parse("#E6E8EC")),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(6),
            Tag = false,
        };

        bool? dialogResult = null;
        okBtn.Click += (_, _) => { dialogResult = true; win.Close(); };
        cancelBtn.Click += (_, _) => { dialogResult = false; win.Close(); };

        btnBar.Children.Add(okBtn);
        if (cancelText != null) btnBar.Children.Add(cancelBtn);
        DockPanel.SetDock(btnBar, Dock.Bottom);
        panel.Children.Add(btnBar);

        var body = new StackPanel { Spacing = 8 };
        body.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 16,
            FontWeight = FontWeight.SemiBold,
            Foreground = GetBrush("TextPrimary") ?? Brushes.Black,
        });
        body.Children.Add(new TextBlock
        {
            Text = message,
            FontSize = 13,
            Foreground = GetBrush("TextSecondary") ?? Brushes.Gray,
            TextWrapping = TextWrapping.Wrap,
        });
        panel.Children.Add(body);

        win.Content = panel;
        win.Closed += (_, _) => { if (dialogResult == null) dialogResult = false; };
        var tcs = new System.Threading.Tasks.TaskCompletionSource<bool>();
        win.Tag = tcs;
        win.Closed += (_, _) => tcs.TrySetResult(dialogResult ?? false);
        return win;
    }

    private async System.Threading.Tasks.Task<bool> ShowDialogAsync(Window dialog)
    {
        var owner = TopLevel.GetTopLevel(this) as Window;
        var tcs = dialog.Tag as System.Threading.Tasks.TaskCompletionSource<bool>;
        if (owner != null)
            await dialog.ShowDialog(owner);
        else
            dialog.Show();
        if (tcs != null) return await tcs.Task;
        return false;
    }

    private async void ShowDialog(string title, string message)
    {
        var dlg = CreateDialog(title, message, "确定", null);
        await ShowDialogAsync(dlg);
    }

    private async System.Threading.Tasks.Task<bool> ShowConfirmDialog(string title, string message)
    {
        var dlg = CreateDialog(title, message, "确定", "取消");
        return await ShowDialogAsync(dlg);
    }
}
