using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.Settings.ViewModels;

/// <summary>
/// 加密DNS 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class DnsViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "加密DNS";
    [ObservableProperty] private string _pageIcon = "🔒";
    [ObservableProperty] private string _pageDescription = "系统 DNS 与加密 DNS（DoH/DoT）配置。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
