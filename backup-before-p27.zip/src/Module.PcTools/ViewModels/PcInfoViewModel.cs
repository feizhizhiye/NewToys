using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.PcTools.ViewModels;

/// <summary>
/// 系统信息 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class PcInfoViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "系统信息";
    [ObservableProperty] private string _pageIcon = "💻";
    [ObservableProperty] private string _pageDescription = "硬件、系统版本、网络状态等信息一览。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
