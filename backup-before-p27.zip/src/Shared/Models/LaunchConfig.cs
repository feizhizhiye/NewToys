namespace NewToys.Shared.Models;

public class LaunchConfig
{
    public bool StartWithSystem { get; set; } = false;
    public bool StartMinimized { get; set; } = false;
    public bool CheckUpdateOnStartup { get; set; } = true;
}
