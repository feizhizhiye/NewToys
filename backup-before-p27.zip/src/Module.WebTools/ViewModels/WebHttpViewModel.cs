using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.WebTools.ViewModels;

/// <summary>
/// HTTP测试 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class WebHttpViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "HTTP测试";
    [ObservableProperty] private string _pageIcon = "🧪";
    [ObservableProperty] private string _pageDescription = "HTTP/HTTPS 请求测试，支持 GET/POST/自定义 Header。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
