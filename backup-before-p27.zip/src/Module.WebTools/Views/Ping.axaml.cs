using Avalonia.Controls;

namespace NewToys.Module.WebTools.Views;

public partial class Ping : UserControl
{
    public Ping()
    {
        InitializeComponent();
    }
}
