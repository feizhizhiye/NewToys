using CommunityToolkit.Mvvm.ComponentModel;
using NewToys.Shared.Models;
using System.Collections.ObjectModel;

namespace NewToys.Module.Settings.ViewModels;

public partial class LaunchAppItem : ObservableObject
{
    [ObservableProperty] private string _name = "";
    [ObservableProperty] private string _path = "";
}

public partial class LaunchConfigViewModel : ObservableObject
{
    [ObservableProperty] private bool _startWithSystem;
    [ObservableProperty] private bool _startMinimized;
    [ObservableProperty] private bool _checkUpdateOnStartup = true;

    public ObservableCollection<LaunchAppItem> Apps { get; } = new()
    {
        new LaunchAppItem { Name = "（示例）浏览器1", Path = "暂未配置" },
        new LaunchAppItem { Name = "（示例）微信",     Path = "暂未配置" },
    };
}
