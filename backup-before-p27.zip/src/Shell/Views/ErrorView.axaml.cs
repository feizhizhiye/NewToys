using Avalonia.Controls;

namespace NewToys.Shell.Views;

public partial class ErrorView : UserControl
{
    public ErrorView()
    {
        InitializeComponent();
    }

    public void SetError(string message)
    {
        if (ErrorMessage != null)
            ErrorMessage.Text = message;
    }
}
