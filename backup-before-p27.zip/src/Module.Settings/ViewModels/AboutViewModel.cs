using CommunityToolkit.Mvvm.ComponentModel;
using NewToys.Core.Services;
using System.Collections.Generic;
using System.Linq;

namespace NewToys.Module.Settings.ViewModels;

/// <summary>技术栈条目（强类型，避免 axaml 编译绑定无法识别 ValueTuple 命名字段）。</summary>
public class TechStackItem
{
    public string Name { get; set; } = "";
    public string Version { get; set; } = "";
    public string Display => $"{Name}  {Version}";
}

public partial class AboutViewModel : ObservableObject
{
    private readonly AppConfigService _config;

    public string AppName => _config.AppName;
    public string Version => _config.Version;

    public IReadOnlyList<TechStackItem> TechStack { get; }
    public IReadOnlyList<string> CoreConstraints { get; }

    public AboutViewModel(AppConfigService config)
    {
        _config = config;
        TechStack = config.TechStack.Select(t => new TechStackItem { Name = t.Name, Version = t.Version }).ToList();
        CoreConstraints = config.CoreConstraints;
    }
}
