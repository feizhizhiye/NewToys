using Avalonia.Controls;

namespace NewToys.Module.PcTools.Views;

public partial class Favorites : UserControl
{
    public Favorites()
    {
        InitializeComponent();
    }
}
