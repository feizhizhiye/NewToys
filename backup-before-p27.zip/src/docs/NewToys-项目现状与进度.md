# NewToys 项目现状与进度

> 版本：v1.12 ｜ 最后更新：2026-10-09
> 本文件用于**跨会话续作**：新会话接手时，先读本文件即可掌握"做到哪了、下一步做什么"。

---

## 一、当前基线

| 项 | 内容 |
|---|---|
| 工程版本 | **v1.1（骨架阶段）** |
| 基线组成 | v1.1 整包 → 补丁6（主题加载崩溃修复）→ 补丁7（首页重构 + 首页隐藏第二列）→ 补丁8（规范 v1.4）→ 补丁9（规范 v1.5：框架冻结 + 模块功能清单 + 经验教训）→ 补丁10（规范 v1.6：交付链接硬规则 + 交付自检清单）→ 补丁11（规范 v1.7：工程结构与运行环境约束）→ 补丁12（规范 v1.8：免 zip 交接 + 二级兜底通道）→ 补丁14（规范 v1.9：源码快照导出/导入三脚本）→ 补丁15（规范 v1.10：源码快照脚本往返修复 + 补丁14 遗漏项补全）→ 补丁16（规范 v1.11：补丁命名简化 + 标准工作流 + 文档合并评估）→ **补丁17（规范 v1.12：文档合并为 3 份 · 方案 A）** |
| 最近补丁 | `p17-docmerge.patch`（规范 v1.12） |
| 文档版本 | 规范 / 现状 / AI协作提示词 均为 **v1.12**（docs 下共 **3 份**；v1.12 由原 5 份合并） |
| 编译状态 | Debug **0 Error / 0 Warning**；Release **0 Error / 0 Warning** |
| 技术栈 | .NET 10 + Avalonia 12.1.3 + CommunityToolkit.Mvvm 8.4.2 + MEDI 9.0.0 |
| 仓库根 | 能看到 `src/` 的那一级 |

---

## 二、已完成（可视为"已验证"）

### 2.0 框架层状态（重要）
- 🔒 **`Shared` / `Core` / `Shell` 为框架层，已进入冻结状态**：骨架稳定，后续功能演进**只在 `Module.*` 内**；确需改框架层须先经用户同意（见规范 4.1.1）。
- ✅ 命名以现有工程为准：模块 `RootNamespace = NewToys.Module.<模块名>`、`AssemblyName = Module.<模块名>`；`Shell.AssemblyName = NewToys`（见规范 4.4）。

### 2.1 架构与骨架
- ✅ **7 个项目**：`Shared` / `Core` / `Shell` + 4 个模块（`Module.PcTools` / `Module.WebTools` / `Module.VideoTools` / `Module.Settings`）。
- ✅ 分层依赖单向：`Shared ← Core ← Shell ← Module.*`（模块不引用 Shell）。
- ✅ 中央包版本管理（`Directory.Packages.props`）。
- ✅ DI 容器 + `IModule` 插件机制 + 菜单服务 + 导航服务。
- ✅ **Debug / Release 分离加载**：
  - Debug：`App.axaml.cs` 的 `#if DEBUG` 清单（`typeof(XxxModule)`）+ `Shell.csproj` 条件 `ProjectReference`；注释某模块两处即跳过。
  - Release：Shell 不引用模块，运行时扫描 `NewToys.exe` 同级 `Modules/` 目录。
- ✅ **源码快照导出/导入脚本（v1.9 新增）**：`scripts/export-framework.ps1`、`scripts/export-module.ps1 <名>`、`scripts/import-sources.ps1 <md>`；支持把框架/模块源码导出为**单个 markdown**上传给 AI（不依赖 zip），AI 返回的 md 可一键反向还原到 `src/`，自动备份。

### 2.2 UI（仿微信）
- ✅ **三栏布局**：第一列 66px 深色主菜单 ｜ 第二列 260px 二级菜单 ｜ 第三列自适应内容区。
- ✅ **首页隐藏第二列**（`66,*` 两栏全宽），首页不显示二级菜单。
- ✅ **⚙ 系统设置固定在第一列最底部**（`Order=999`）；🏠 首页按钮在 Dock 上半部。
- ✅ **自定义标题栏** 40px（`WindowDecorations=None`，最小化/最大化/关闭，可拖动）。
- ✅ **明暗主题全局切换**：标题栏 / 二三列 / 卡片 / 文字 / 状态栏全部跟随；主题**纯代码构建 ResourceDictionary**；持久化到 `var/config/theme.json`。
- ✅ 选中态：第一列图标左侧 3px 微信绿指示条（`#07C160`）、选中底色 `#444444`；二级菜单选中底色 `#D9EDDF`。

### 2.3 首页（v1.1 新版）
- ✅ 两栏布局：欢迎卡 + **6 张收藏占位卡片** + **3 个一键操作按钮** + 右上角 ⚙ 设置跳转。
- ✅ 收藏卡：`💻 电脑信息`、`⌨ 快捷键管理`、`🔗 网址检测`、`🎞 视频库`、`🌐 DNS`、`📦 应用设置`（当前硬编码，点击可跳对应页）。
- ⚠️ 3 个一键按钮（`QuickBrowser1` / `QuickBrowser2` / `QuickLaunchApps`）**目前是桩**，仅输出调试日志。

### 2.4 导航与占位机制
- ✅ 菜单点击 → 导航服务 → 内容区切换，链路完整、不崩溃。
- ✅ 页面解析：`ViewModelType`（程序集限定名）→ 找已加载程序集 → 匹配 `XxxView`；**找不到自动回退占位页**。
- ✅ 因此**可先注册菜单、后补页面**，补齐后自动生效，无需改 Shell/Core/Shared。

---

## 三、菜单清单（已注册 22 个二级菜单项）

| 分组 | Key | Order | 二级菜单项 |
|---|---|---|---|
| 首页 | `home` | 0 | （无二级菜单，特殊） |
| PC 工具箱 | `pc` | 10 | pc-home 工具箱首页 / pc-quick 快捷设置 / pc-shortcuts 我的快捷方式 / pc-favorites 收藏夹 / pc-info 系统信息 / pc-winget 软件包管理 |
| Web 工具箱 | `web` | 20 | web-home 工具箱首页 / web-http HTTP测试 / web-bookmark 书签管理 / web-ping 网络Ping / web-scrape 网页抓取 |
| 视频工具箱 | `video` | 30 | video-list 视频库 / video-cut 视频剪辑 / video-transcode 格式转码 |
| 系统设置 | `settings` | 999 | settings-theme 主题外观 / settings-general 通用设置 / settings-launch 启动配置 / settings-path 路径配置 / settings-dns 加密DNS / settings-data 数据管理 / settings-functions 功能清单 / settings-about 关于 |

> **真实实现的页面目前只有 1 个**：`settings-theme`（`ThemeView` + `ThemeViewModel`）。
> 其余 **21 项全部走占位页**（显示"该页面尚未实现"），等贴源码后逐个补齐。

---

## 四、待办 / 下一步（按优先级）

### 4.1 首页增强（用户已明确提出）
1. **三个一键按钮的真实逻辑**：
   - 「浏览器配置 1 批量打开网址」
   - 「浏览器配置 2 批量打开网址」
   - 「批量打开软件」
   - 需要：网址列表 / 浏览器配置（浏览器路径 + 参数）/ 软件列表，可配置、可保存。
   - 首页按钮旁**提供跳转到 Settings 的入口**去编辑这些配置。
2. **收藏夹可固定 / 取消固定**：把常用功能项固定到首页，配置持久化。

### 4.2 模块页面实现
- 按用户提供的 WPF 版源码，逐页迁移到 Avalonia（每个页面 = 一个 `XxxViewModel` + `XxxView.axaml`）。
- 迁移顺序待用户指定；用户会「贴一个页面源码 → 出一个补丁」。

### 4.3 已知小问题（技术债）
- `Core/Services/AppConfigService.cs` 的 `Version` 仍为 `"v0.1.11"`（属框架层，改动前需用户确认）。
- `Shell/Views/ErrorView.axaml` 目前**未被引用**（导航兜底已在 `NavigationService` 内置），可保留或后续清理。
- `Shell/ViewModels/PlaceholderViewModel.cs`、`PlaceholderView` 为占位机制服务，**勿删**。

### 4.4 各模块功能参考
- 各模块的功能职责、页面清单、对应 WPF 源码参考，见 `NewToys开发规范.md` **4.5 各模块功能清单**。
- 原则：**功能参考 WPF 版，结构与命名按现有 Avalonia 工程**。

### 4.5 工程结构约束（补丁11 已完成）
- ✅ 规范新增 **第 13 章「工程结构与运行环境约束」**：真相源原则、仓库目录结构表、目录与命名硬约束、云端工作台结构、新会话交接协议、结构自检。
- ✅ 核心结论：**唯一真相源是用户本地 git 仓库；云端沙箱只是临时工作台（随时会被重置），成果必须以补丁形式回到本地**。
- ✅ 新增概念：**工作区角色目录**（`NewToys/` 工作区、`patches/` 归档、`_baseline/`、`_verify/`、`_inbox/`），禁止根目录散落文件。

### 4.6 交付规范强化（补丁10 已完成）
- ✅ 新增 `NewToys-交付自检清单.md`（交付门禁，每次交付逐项打勾）。
- ✅ 规范第 10 章重写：补充「事故复盘（6 类根因）」+ 8 条交付硬规则；明确 **先落盘再声明 / 标签独立成行 / 文件名单 ASCII**。
- ✅ 约束提示词第六章扩为 10 条「必须」+ 7 条「禁止」；禁止行为总清单扩到 14 条。
- ✅ AI 协作提示词第 5、6 步强化为可机械执行的门禁步骤。
- 目的：根治本项目**反复出现的"说给了链接、用户却拿不到"**问题。

### 4.7 上传通道与兜底（补丁12 已完成）
- ✅ **实测结论：本环境不接收 zip / 压缩包**（上传只会落地单文件，压缩包不落地）。
- ✅ 交接协议（规范 13.5）改为**免 zip、正文粘贴优先**；明确"可用通道"表，**禁止把上传 zip 写进交接要求**。
- ✅ 交接材料**最小化**：3 份文档正文 + 基线声明（"已应用到补丁 N"）+ 目标文件（1–5 个），**不必上传整仓**。
- ✅ 新增交付**二级兜底通道**（规范 10.2 规则 9）：用户反馈"没有链接"时 → 先**单独重发**下载标签 → 仍不行则**把补丁正文分片贴出**，用户手动存盘后 `git apply`。

### 4.8 规范 v1.11（补丁16 已完成）
- ✅ **补丁命名简化**：由 `NewToys-src-<日期>-<序号>-<中文slug>.patch` 改为 **`p<NN>-<slug>.patch`**（短、纯 ASCII、可手打），便于用户手动 `git apply`。
- ✅ **标准工作流落文档**：规范新增 **第 15 章「标准工作流（日常闭环）」**，串联「导出快照 → 提需求 → AI 交付 → 本地落地 → 回写台账」，并给出 patch 与 sources md 的选型建议。
- ✅ **文档合并评估**：规范新增 0.1「文档职责矩阵 + 单一权威原则」、0.2「文档合并评估」，给出 **3 份（推荐）/ 5 份（保守）** 两种方案；因《约束提示词》此前被用户要求保留，**合并需用户确认后执行**（→ 用户已确认，见 4.9，v1.12 已合并为 3 份）。
- ✅ 5 份文档版本号统一递增至 **v1.11**；规范目录与正文顺序修正（第 14、15 章归位，附录 A 移至文末）。


### 4.9 文档合并（方案 A，补丁17 已完成 · v1.12）
- ✅ **5 份 → 3 份**：原《开发约束提示词》并入 `NewToys开发规范.md` **第 11 章**；原《交付自检清单》并入 `NewToys-AI协作提示词.md` **附录 A**；两份原文件**已删除**。
- ✅ 规范**第 0 章重写**：文档体系（3 份）、0.1 职责矩阵与单一权威原则、0.2 合并记录。
- ✅ 规范**第 11 章重写**：`11.1 分主题速查`（布局/架构/启动导航/编码/模块加载/交付/工程结构）+ `11.2 必须` + `11.3 禁止`。
- ✅ 三份文档版本号统一递增至 **v1.12**；全部交叉引用改指新位置。
- ✅ **收益**：每次改动只需同步 2–3 份；规则只在权威处定义一次。

---

## 五、关键文件索引

| 关注点 | 文件 |
|---|---|
| 启动入口 / DI / 启动时序 / 主题字典 | `src/Shell/App.axaml.cs` |
| 主窗口（三栏布局 / 列切换 / 导航栏构建） | `src/Shell/Views/ShellView.axaml(.cs)` |
| Shell 状态（IsHomePage / SelectedGroup / SelectedItem） | `src/Shell/ViewModels/ShellViewModel.cs` |
| 首页（欢迎卡 / 收藏 / 一键按钮） | `src/Shell/Views/HomeView.axaml` + `src/Shell/ViewModels/HomeViewModel.cs` |
| 导航服务（页面解析 / 占位兜底） | `src/Shell/Services/NavigationService.cs` |
| 模块加载（Debug 清单 / Release 扫描） | `src/Core/Services/ModuleLoader.cs` |
| 菜单服务（内置首页 / 分组排序） | `src/Core/Services/MenuService.cs` |
| 主题服务（持久化 theme.json） | `src/Core/Services/ThemeService.cs` |
| 主题设置页 | `src/Module.Settings/Views/ThemeView.axaml` + `ViewModels/ThemeViewModel.cs` |
| 契约与模型 | `src/Shared/Models/*`、`src/Shared/Services/*` |
| 包版本 | `src/Directory.Packages.props` |
| 构建脚本 | `scripts/{build,run,clean,publish}.ps1` |
| 交付门禁 | `src/docs/NewToys-AI协作提示词.md` 附录 A（每次交付必过） |

---

## 六、如何在新会话继续

0. **先确认真相源**：以本地 git 仓库为准。**用正文粘贴**把 `src/docs/` 下 3 份文档正文发给 AI，并声明"已应用到补丁 N"（本环境**不接收 zip**，见规范 13.5.1）。云端不存东西，AI 只负责产出补丁。
1. 新会话开头，把 `src/docs/NewToys-AI协作提示词.md` 的「提示词正文」整段发给 AI。
2. 在末尾追加你的需求（要做的功能 / 贴的源码 / 报错信息）。
3. AI 会：读规范（含第 10 章 + 交付自检清单，即 AI 协作提示词附录 A）→ 摸底 → 按规范改 `src/` → Debug/Release 编译验证 → **落盘补丁并验证存在** → 给出**下载链接 + 变更清单 + 应用步骤 + 验证记录**。
4. 本地仓库根目录执行（补丁名为短名，如 `p16-workflow.patch`）：
   ```bash
   git apply --check "p16-xxx.patch"
   git apply "p16-xxx.patch"
   git add -A && git commit -m "<type>: <简述>"
   ```

> **若 AI 没给下载链接**：直接引用 `NewToys-AI协作提示词.md` 附录 A 要求它重新交付——**不给链接不算交付**。
> 若反复拿不到：要求它走**二级兜底通道**——先**单独重发**下载标签；仍不行则**把补丁正文分片贴出**，你手动存成 `.patch` 再 `git apply`（补丁是纯文本，不依赖链接）。
> 建议每次应用补丁后，让 AI 同步更新本文件的「已完成 / 待办 / 基线」三节。

---

## 七、工程结构一览（真相源与目录约定）

> 完整规则见 `NewToys开发规范.md` **第 13 章**。此处只列速查。

### 7.1 真相源
- **唯一真相源 = 用户本地 git 仓库**（含 `src/`、`scripts/`、`src/docs/`）。
- **云端沙箱 = 临时工作台**，随时可能被重置；成果一律以 **`git apply` 补丁**回到本地。
- 流转载体只有两类：① 用户以**正文粘贴 / 单文件上传**提供的基线材料；② AI 产出的补丁。**本环境不接收 zip**（见规范 13.5.1）。

### 7.2 仓库目录（速查）

```
NewToys/                      仓库根（能看到 src/ 的那一级）
├── src/                      唯一源码真相源（入 git）
│   ├── Shared/  Core/  Shell/
│   ├── Module.PcTools/  Module.WebTools/  Module.VideoTools/  Module.Settings/
│   ├── Directory.Build.props   Directory.Packages.props   NewToys.slnx
│   └── docs/                 3 份规范文档（宪法，不得删/移/改名）
├── scripts/                  构建脚本（用户维护，AI 默认不改）
├── patches/                  交付补丁归档（建议入 git）
├── artifacts/                编译中间产物（忽略）
├── Modules/                  模块 DLL，与 NewToys.exe 同级（忽略）
├── var/                      运行数据 config/logs/cache/temp（忽略）
├── production/               发布产物（忽略）
├── .gitignore  global.json  README*.md
```

### 7.3 目录硬约束
- ✅ 新增**顶层目录**须先在规范登记。
- ✅ 源码只在 `src/`；生成物只在忽略目录。
- ✅ 交付件文件名**纯 ASCII**。
- ❌ 仓库根禁止散落补丁 / 临时文件 / 截图。

### 7.4 云端工作台角色目录（AI 侧）
`NewToys/`（工作区）｜`patches/`（归档）｜`_baseline/`（基线快照）｜`_verify/`（验证副本）｜`_inbox/`（用户素材）。
多副本时：**以 `src/docs/` 版本号最大者为真相源**，其余标为 baseline / verify。

### 7.5 新会话交接 6 步（**免 zip**）
取料（**粘贴 3 份文档正文 + 声明基线**）→ 定位真相源 → 读 3 份宪法 → 确认基线 → 小步交付 → 回写台账。
> 通道：**正文粘贴优先**；单文件上传可选；**禁止 zip**。材料最小化——文档 + 基线声明 + 目标文件即可，不必整仓。

---

## 八、源码快照导出/导入（v1.9 新增协作机制，重要）

> 详见规范 **第 14 章**。本环境不接收 zip/压缩包，新会话续作**必须**使用此机制。

### 8.1 三个脚本
| 脚本 | 作用 |
|---|---|
| `pwsh ./scripts/export-framework.ps1` | 导出框架层（Shared/Core/Shell + 根配置）到 `sources/framework.md` |
| `pwsh ./scripts/export-module.ps1 <模块名>` | 导出单个模块到 `sources/module-<name>.md`（如 `PcTools`/`Settings`） |
| `pwsh ./scripts/import-sources.ps1 <md文件>` | 解析 md 中的 `FILE:` 段反向写入 `src/`，自动备份原文件到 `.sources-import-backup/`；加 `-DryRun` 只预览不写入 |

### 8.2 新会话续作流程
```
1. 你本地：
   pwsh ./scripts/export-framework.ps1          → sources/framework.md
   pwsh ./scripts/export-module.ps1 PcTools     → sources/module-pctools.md（按需）

2. 新会话：
   开场白贴 src/docs/NewToys-AI协作提示词.md 正文
   上传 framework.md（首次必须）+ 需要改的 module-xxx.md
   说需求/贴 WPF 参考源码

3. AI 改完：
   返回 1 个 sources md 文件（优先）或 git patch，附下载链接

4. 你本地还原：
   pwsh ./scripts/import-sources.ps1 sources/xxx.md -DryRun   # 预览
   pwsh ./scripts/import-sources.ps1 sources/xxx.md            # 实际写入
   pwsh ./scripts/run.ps1                                      # 编译验证
   git add -A && git commit
```

### 8.3 为什么用单 md 而不是 zip
- ✅ 单文件可直接上传/粘贴；
- ✅ 带元信息（模块名/导出时间/版本）；
- ✅ 机器可解析、可反向还原；
- ✅ 天然支持 -DryRun 预览 + 自动备份；
- ✅ 与 git patch 互补（sources md = 快照，patch = diff）。

### 8.4 往返修复记录（v1.10，重要）

v1.9 首次交付的三个脚本存在**导致机制失效的实现缺陷**，v1.10 已修复并经**真实往返实测**：

| # | 缺陷 | 影响 | 修复 |
|---|---|---|---|
| 1 | **补丁14 未包含三个脚本本身** | 用户 `git apply` 后只拿到文档，**脚本根本不在仓库里**，机制无法使用 | 补丁15 把 `export-framework.ps1` / `export-module.ps1` / `import-sources.ps1` 作为新文件一并交付 |
| 2 | **导出写 3 个反引号，导入却按 6 个匹配** | PowerShell 双引号里 6 个反引号被转义成 3 个；**反向导入一个文件都解析不到** | 导出改用 `$Fence = '`' * 6` 变量；导入改为**动态匹配 3 个及以上**围栏，并以与开启行等长的那行为结束 |
| 3 | **导入丢失文件尾换行** | 每个被导入文件都产生 `\ No newline at end of file` diff，30+ 文件全变「已修改」 | 新增 `Write-SourceFile`：**保留原文件换行风格（CRLF/LF）**、文件尾**恰好一个换行**、UTF-8 **无 BOM** |
| 4 | 导入对 `src/` 前缀不兼容 | 若 AI 按文档旧示例写成 `FILE: src/xxx`，会落到 `src/src/xxx` | 导入**自动去掉**开头的 `./` 与 `src/`；文档示例同步更正为「相对 `src/`、不带前缀」 |
| 5 | `export-module.ps1` 报错时不列出可用模块 | `$ErrorActionPreference='Stop'` 使 `Write-Error` 立即终止，列表永不打印 | 改为先把可用模块拼进错误消息再抛出 |

**修复验证（真实执行，非口头）**：PowerShell 7.6.6 下跑通「导出 → 模拟 AI 改/增/删 → DryRun 预览 → 实际导入」全链路：

- 框架往返 34 个文件**逐字节零差异**；
- 修改 / 新增 / 删除三类操作全部正确落盘；
- 路径穿越 `../../evil-outside.txt` 被 **SKIP**，未在 src 外产生任何文件；
- 自动备份含改动前版本，可回滚；
- 重复导入幂等。
