using System.Collections.Generic;

namespace NewToys.Core.Services;

public class AppConfigService
{
    public string AppName { get; set; } = "NewToys";
    public string Version { get; set; } = "v0.1.12";

    /// <summary>技术栈版本清单，供"关于"页展示，版本号与 Directory.Packages.props 保持一致。</summary>
    public IReadOnlyList<(string Name, string Version)> TechStack { get; } = new[]
    {
        (".NET", "10"),
        ("Avalonia", "12.1.3"),
        ("CommunityToolkit.Mvvm", "8.4.2"),
        ("Microsoft.Extensions.DependencyInjection", "9.0.0"),
        ("Microsoft.Extensions.Configuration", "9.0.0"),
        ("Microsoft.Extensions.Logging", "9.0.0"),
    };

    /// <summary>项目核心约束，供"关于"页展示，与 src/docs/NewToys开发规范.md 第 11 章保持一致。</summary>
    public IReadOnlyList<string> CoreConstraints { get; } = new[]
    {
        "7 项目骨架：Shared / Core / Shell / Module.PcTools / Module.WebTools / Module.VideoTools / Module.Settings",
        "分层单向依赖：Shell → Module.* → Core → Shared；Module.* 禁止引用 Shell",
        "框架层（Shared/Core/Shell）冻结，模块插件化开发，Release 走 Modules 目录动态加载",
        "三栏仿微信布局：66px 侧栏 + 260px 二级菜单 + 自适应内容区；首页为两栏模式",
        "首页为常用功能聚合区，支持收藏卡一键直达二级页面，底部三个一键按钮配专属快捷设置",
        "MVVM + CommunityToolkit.Mvvm 源生成器（[ObservableProperty] / [RelayCommand]），禁止手写 INotifyPropertyChanged",
        "配置与状态落盘到 var/config/，所有配置文件支持备份导出与一键导入",
    };
}
