using Avalonia.Controls;

namespace NewToys.Module.VideoTools.Views;

public partial class VideoList : UserControl
{
    public VideoList()
    {
        InitializeComponent();
    }
}
