using Avalonia.Controls;

namespace NewToys.Module.Settings.Views;

public partial class AllFunctions : UserControl
{
    public AllFunctions()
    {
        InitializeComponent();
    }
}
