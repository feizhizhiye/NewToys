using Avalonia.Controls;

namespace NewToys.Module.Settings.Views;

public partial class AboutView : UserControl
{
    public AboutView()
    {
        InitializeComponent();
    }
}
