using Avalonia.Controls;

namespace NewToys.Module.Settings.Views;

public partial class LaunchConfigView : UserControl
{
    public LaunchConfigView() { InitializeComponent(); }
}
