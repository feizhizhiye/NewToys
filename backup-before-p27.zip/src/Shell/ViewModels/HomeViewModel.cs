using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.DependencyInjection;
using CommunityToolkit.Mvvm.Input;
using NewToys.Shared.Models;
using NewToys.Shared.Services;
using System.Collections.ObjectModel;

namespace NewToys.Shell.ViewModels;

public partial class HomeFavoriteItem : ObservableObject
{
    [ObservableProperty] private string _icon = "📌";
    [ObservableProperty] private string _title = "";
    [ObservableProperty] private string _description = "";
    [ObservableProperty] private string _navigateKey = "";
}

public partial class HomeViewModel : ViewModelBase
{
    [ObservableProperty] private string _welcomeText = "欢迎使用 NewToys";
    [ObservableProperty] private string _subText = "个人高强度使用工具集 · 基于 Avalonia 12 + .NET 10";

    public ObservableCollection<HomeFavoriteItem> Favorites { get; } = new();

    public HomeViewModel()
    {
        // 常用功能（NavigateKey 直接指向二级菜单 Key，点击后直达对应页面）
        Favorites.Add(new HomeFavoriteItem { Icon = "💻", Title = "电脑信息",    Description = "硬件、系统、网络概览",     NavigateKey = "pc-info" });
        Favorites.Add(new HomeFavoriteItem { Icon = "⌨",  Title = "快捷键管理",  Description = "我的快捷键与自定义操作",    NavigateKey = "pc-shortcuts" });
        Favorites.Add(new HomeFavoriteItem { Icon = "🔗", Title = "网址检测",    Description = "批量书签可用性检测",        NavigateKey = "web-bookmark" });
        Favorites.Add(new HomeFavoriteItem { Icon = "🎞", Title = "视频库",      Description = "本地视频管理与预览",        NavigateKey = "video-list" });
        Favorites.Add(new HomeFavoriteItem { Icon = "🌐", Title = "DNS设置",     Description = "加密DNS与网络配置",         NavigateKey = "settings-dns" });
        Favorites.Add(new HomeFavoriteItem { Icon = "📦", Title = "应用设置",    Description = "通用、主题、启动项",        NavigateKey = "settings-general" });
    }

    /// <summary>收藏卡点击：直接跳转到对应二级菜单页面，不停留在模块首页。</summary>
    [RelayCommand]
    private void FavoriteClick(HomeFavoriteItem? item)
    {
        if (item == null || string.IsNullOrEmpty(item.NavigateKey)) return;
        var shell = Ioc.Default.GetService<ShellViewModel>();
        shell?.NavigateToPage(item.NavigateKey);
    }

    #region 底部三个一键按钮：主操作 + 对应"快捷设置"

    /// <summary>浏览器1 快捷设置：跳转到"路径配置"页（浏览器路径/网址列表配置）。</summary>
    [RelayCommand]
    private void QuickSettingsBrowser1() => NavigateToSettings("settings-path");

    /// <summary>浏览器2 快捷设置：同样跳转到"路径配置"页，后续可扩展为独立的浏览器2配置子页。</summary>
    [RelayCommand]
    private void QuickSettingsBrowser2() => NavigateToSettings("settings-path");

    /// <summary>批量启动软件 快捷设置：跳转到"启动配置"页。</summary>
    [RelayCommand]
    private void QuickSettingsApps() => NavigateToSettings("settings-launch");

    private static void NavigateToSettings(string key)
    {
        var shell = Ioc.Default.GetService<ShellViewModel>();
        if (shell != null) shell.NavigateToPage(key);
    }

    // 三个一键按钮（先占位，后续按你给的WPF源码实现真实逻辑）
    [RelayCommand]
    private void QuickBrowser1() => System.Diagnostics.Debug.WriteLine("QuickBrowser1 clicked");
    [RelayCommand]
    private void QuickBrowser2() => System.Diagnostics.Debug.WriteLine("QuickBrowser2 clicked");
    [RelayCommand]
    private void QuickLaunchApps() => System.Diagnostics.Debug.WriteLine("QuickLaunchApps clicked");

    #endregion
}
