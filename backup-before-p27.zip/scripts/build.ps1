param(
    [ValidateSet("Debug", "Release")]
    [string]$Configuration = "Debug"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptDir
$SrcDir = Join-Path $RepoRoot "src"
$ArtifactsRoot = Join-Path $RepoRoot "artifacts\bin"
$ShellOutputDir = Join-Path $ArtifactsRoot "Shell\$Configuration\net10.0"
$ModulesOutputDir = Join-Path $ShellOutputDir "Modules"

Write-Host "==> 构建配置: $Configuration" -ForegroundColor Cyan
Write-Host "==> 源码目录: $SrcDir"
Write-Host "==> 输出目录: $ArtifactsRoot"

# 还原 + 编译
Push-Location $SrcDir
try {
    Write-Host "`n==> 还原NuGet包..." -ForegroundColor Cyan
    dotnet restore
    if ($LASTEXITCODE -ne 0) { throw "dotnet restore 失败" }

    Write-Host "`n==> 编译项目..." -ForegroundColor Cyan
    dotnet build -c $Configuration --no-restore
    if ($LASTEXITCODE -ne 0) { throw "dotnet build 失败" }
}
finally {
    Pop-Location
}

# 复制模块DLL到Shell输出目录的Modules文件夹
Write-Host "`n==> 同步模块DLL到 $ModulesOutputDir" -ForegroundColor Cyan
if (-not (Test-Path $ModulesOutputDir)) {
    New-Item -ItemType Directory -Path $ModulesOutputDir -Force | Out-Null
}

# 收集需要复制的模块DLL（Shared/Core/所有Module.*）
$assembliesToCopy = @(
    "NewToys.Shared.dll",
    "NewToys.Core.dll"
)

# Debug模式：DLL都在Shell输出目录，直接复制
if ($Configuration -eq "Debug") {
    foreach ($asm in $assembliesToCopy) {
        $src = Join-Path $ShellOutputDir $asm
        if (Test-Path $src) {
            Copy-Item $src -Destination $ModulesOutputDir -Force
            Write-Host "  [DEBUG] 复制 $asm" -ForegroundColor Gray
        }
    }
    # 找所有模块DLL
    Get-ChildItem $ShellOutputDir -Filter "NewToys.Module.*.dll" | ForEach-Object {
        Copy-Item $_.FullName -Destination $ModulesOutputDir -Force
        Write-Host "  [DEBUG] 复制 $($_.Name)" -ForegroundColor Gray
    }
}
# Release模式：DLL在各模块自己的输出目录
else {
    # 复制Shared/Core
    foreach ($proj in @("Shared", "Core")) {
        $src = Join-Path $ArtifactsRoot "$proj\$Configuration\net10.0\NewToys.$proj.dll"
        if (Test-Path $src) {
            Copy-Item $src -Destination $ModulesOutputDir -Force
            Write-Host "  [RELEASE] 复制 NewToys.$proj.dll" -ForegroundColor Gray
        }
    }
    # 复制所有Module
    Get-ChildItem $SrcDir -Directory -Filter "Module.*" | ForEach-Object {
        $moduleName = $_.Name
        $src = Join-Path $ArtifactsRoot "$moduleName\$Configuration\net10.0\NewToys.$moduleName.dll"
        if (Test-Path $src) {
            Copy-Item $src -Destination $ModulesOutputDir -Force
            Write-Host "  [RELEASE] 复制 NewToys.$moduleName.dll" -ForegroundColor Gray
        }
    }
}

# 创建var目录
$varDir = Join-Path $RepoRoot "var"
@("config", "logs", "cache", "temp") | ForEach-Object {
    $path = Join-Path $varDir $_
    if (-not (Test-Path $path)) { New-Item -ItemType Directory -Path $path -Force | Out-Null }
}

Write-Host "`n✅ 构建完成! 输出目录: $ShellOutputDir" -ForegroundColor Green
Write-Host "   模块目录: $ModulesOutputDir" -ForegroundColor Green
