using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.PcTools.ViewModels;

/// <summary>
/// 软件包管理 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class WingetViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "软件包管理";
    [ObservableProperty] private string _pageIcon = "📦";
    [ObservableProperty] private string _pageDescription = "基于 winget 的软件安装、升级与卸载管理。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
