using Microsoft.Extensions.DependencyInjection;
using NewToys.Module.Settings.ViewModels;
using NewToys.Shared.Models;
using NewToys.Shared.Services;

namespace NewToys.Module.Settings;

public class SettingsModule : IModule
{
    public void RegisterServices(IServiceCollection services)
    {
        services.AddTransient<ThemeViewModel>();
        services.AddTransient<GeneralViewModel>();
        services.AddTransient<PathViewModel>();
        services.AddTransient<LaunchConfigViewModel>();
        services.AddTransient<DataViewModel>();
        services.AddTransient<DnsViewModel>();
        services.AddTransient<AllFunctionsViewModel>();
        services.AddTransient<AboutViewModel>();
    }

    public void Initialize(IServiceProvider services)
    {
        var menu = services.GetRequiredService<IMenuService>();
        var group = menu.AddGroup("settings", "系统设置", "⚙", order: 999);
        menu.AddItem("settings", new MenuItem { Key = "settings-theme",     Title = "主题外观", ViewModelType = typeof(ThemeViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-general",   Title = "通用设置", ViewModelType = typeof(GeneralViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-launch",    Title = "启动配置", ViewModelType = typeof(LaunchConfigViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-path",      Title = "路径配置", ViewModelType = typeof(PathViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-dns",       Title = "加密DNS",  ViewModelType = typeof(DnsViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-data",      Title = "数据管理", ViewModelType = typeof(DataViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-functions", Title = "功能清单", ViewModelType = typeof(AllFunctionsViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("settings", new MenuItem { Key = "settings-about",     Title = "关于",     ViewModelType = typeof(AboutViewModel).AssemblyQualifiedName ?? "" });
    }
}
