using Avalonia.Controls;

namespace NewToys.Module.WebTools.Views;

public partial class Scrape : UserControl
{
    public Scrape()
    {
        InitializeComponent();
    }
}
