using Microsoft.Extensions.DependencyInjection;
using NewToys.Module.WebTools.ViewModels;
using NewToys.Shared.Models;
using NewToys.Shared.Services;

namespace NewToys.Module.WebTools;

public class WebToolsModule : IModule
{
    public void RegisterServices(IServiceCollection services)
    {
        services.AddTransient<WebHomeViewModel>();
        services.AddTransient<WebHttpViewModel>();
        services.AddTransient<BookmarkViewModel>();
        services.AddTransient<PingViewModel>();
        services.AddTransient<ScrapeViewModel>();
    }

    public void Initialize(IServiceProvider services)
    {
        var menu = services.GetRequiredService<IMenuService>();
        var group = menu.AddGroup("web", "Web工具箱", "🌐", order: 20);
        menu.AddItem("web", new MenuItem { Key = "web-home", Title = "工具箱首页", ViewModelType = typeof(WebHomeViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("web", new MenuItem { Key = "web-http", Title = "HTTP测试", ViewModelType = typeof(WebHttpViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("web", new MenuItem { Key = "web-bookmark", Title = "书签管理", ViewModelType = typeof(BookmarkViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("web", new MenuItem { Key = "web-ping", Title = "网络Ping", ViewModelType = typeof(PingViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("web", new MenuItem { Key = "web-scrape", Title = "网页抓取", ViewModelType = typeof(ScrapeViewModel).AssemblyQualifiedName ?? "" });
    }
}
