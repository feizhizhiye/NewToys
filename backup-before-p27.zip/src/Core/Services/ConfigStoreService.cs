using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace NewToys.Core.Services;

/// <summary>
/// 统一的"配置文件存储"服务：负责定位 var/config 目录、枚举配置文件、
/// 一键打包导出、一键从备份还原。供主题/启动/路径/数据管理等模块共用，
/// 避免每个服务自己拼路径导致 Debug/Release 路径不一致。
/// </summary>
public class ConfigStoreService
{
    private readonly Lazy<string> _configDir;

    public string ConfigDir => _configDir.Value;

    public ConfigStoreService()
    {
        _configDir = new Lazy<string>(ResolveConfigDir);
    }

    /// <summary>定位 var/config 目录，Debug/Release 两种布局都兼容。</summary>
    private static string ResolveConfigDir()
    {
        // Debug：bin/Debug/net10.0/，回退 4 层到仓库根
        var debugDir = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "var", "config");
        if (Directory.Exists(debugDir)) return Path.GetFullPath(debugDir);

        // Release：exe 同级 var/config
        var releaseDir = Path.Combine(AppContext.BaseDirectory, "var", "config");
        Directory.CreateDirectory(releaseDir);
        return Path.GetFullPath(releaseDir);
    }

    /// <summary>返回 var/config 下所有 .json 配置文件（含文件名、相对路径、内容）。</summary>
    public IReadOnlyList<ConfigFileEntry> ListConfigFiles()
    {
        var list = new List<ConfigFileEntry>();
        if (!Directory.Exists(ConfigDir)) return list;
        foreach (var f in Directory.GetFiles(ConfigDir, "*.json", SearchOption.TopDirectoryOnly))
        {
            try
            {
                list.Add(new ConfigFileEntry(
                    name: Path.GetFileName(f),
                    relativePath: Path.GetFileName(f),
                    sizeBytes: new FileInfo(f).Length,
                    lastWriteTime: File.GetLastWriteTime(f),
                    content: File.ReadAllText(f)));
            }
            catch { /* 读不到的跳过，不影响其他文件 */ }
        }
        return list;
    }

    /// <summary>
    /// 将当前 var/config 下全部 json 打包成一份备份 JSON 字符串。
    /// 格式：{ "version": "...", "exportedAt": "...", "files": { "xxx.json": "原文" } }。
    /// </summary>
    public string ExportBackup()
    {
        var files = new Dictionary<string, string>();
        foreach (var entry in ListConfigFiles())
        {
            files[entry.RelativePath] = entry.Content;
        }
        var payload = new BackupPayload
        {
            AppName = "NewToys",
            Version = typeof(ConfigStoreService).Assembly.GetName().Version?.ToString() ?? "0.0.0",
            ExportedAt = DateTimeOffset.Now.ToString("o"),
            Files = files,
        };
        return JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true });
    }

    /// <summary>
    /// 校验一份备份 JSON，返回其中包含的配置文件名列表（失败返回错误消息）。
    /// </summary>
    public (bool Ok, string[] Files, string Error) PeekBackup(string jsonText)
    {
        try
        {
            var payload = JsonSerializer.Deserialize<BackupPayload>(jsonText);
            if (payload == null || payload.Files == null || payload.Files.Count == 0)
                return (false, Array.Empty<string>(), "备份文件为空或格式不正确");
            var names = new string[payload.Files.Count];
            payload.Files.Keys.CopyTo(names, 0);
            return (true, names, "");
        }
        catch (Exception ex)
        {
            return (false, Array.Empty<string>(), "备份文件解析失败：" + ex.Message);
        }
    }

    /// <summary>
    /// 导入备份：
    /// 1) 先把当前 var/config 自动备份为 .bak-时间戳 子目录；
    /// 2) 用备份内容覆盖同名 .json；
    /// 3) 返回覆盖的文件列表与自动备份目录路径。
    /// </summary>
    public (bool Ok, string[] ImportedFiles, string AutoBackupDir, string Error) ImportBackup(string jsonText)
    {
        var (ok, files, peekErr) = PeekBackup(jsonText);
        if (!ok) return (false, Array.Empty<string>(), "", peekErr);

        // 自动备份当前配置
        var ts = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        var autoBackupDir = Path.Combine(ConfigDir, $".bak-{ts}");
        Directory.CreateDirectory(autoBackupDir);
        foreach (var existing in Directory.GetFiles(ConfigDir, "*.json", SearchOption.TopDirectoryOnly))
        {
            try
            {
                File.Copy(existing, Path.Combine(autoBackupDir, Path.GetFileName(existing)), overwrite: true);
            }
            catch { /* 单个备份失败不阻断导入 */ }
        }

        try
        {
            var payload = JsonSerializer.Deserialize<BackupPayload>(jsonText)!;
            var imported = new List<string>();
            foreach (var kv in payload.Files!)
            {
                // 安全约束：禁止路径穿越（只允许根目录下的文件名）
                var name = Path.GetFileName(kv.Key);
                if (string.IsNullOrEmpty(name) || name.Contains("..") || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                    continue;
                var target = Path.Combine(ConfigDir, name);
                File.WriteAllText(target, kv.Value ?? "");
                imported.Add(name);
            }
            return (true, imported.ToArray(), autoBackupDir, "");
        }
        catch (Exception ex)
        {
            return (false, Array.Empty<string>(), autoBackupDir, "导入失败：" + ex.Message);
        }
    }

    public class ConfigFileEntry
    {
        public ConfigFileEntry(string name, string relativePath, long sizeBytes, DateTime lastWriteTime, string content)
        {
            Name = name; RelativePath = relativePath; SizeBytes = sizeBytes;
            LastWriteTime = lastWriteTime; Content = content;
        }
        public string Name { get; }
        public string RelativePath { get; }
        public long SizeBytes { get; }
        public DateTime LastWriteTime { get; }
        public string Content { get; }
    }

    private class BackupPayload
    {
        public string AppName { get; set; } = "";
        public string Version { get; set; } = "";
        public string ExportedAt { get; set; } = "";
        public Dictionary<string, string>? Files { get; set; }
    }
}
