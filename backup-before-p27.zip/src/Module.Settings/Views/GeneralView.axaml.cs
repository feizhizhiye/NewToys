using Avalonia.Controls;

namespace NewToys.Module.Settings.Views;

public partial class GeneralView : UserControl
{
    public GeneralView() { InitializeComponent(); }
}
