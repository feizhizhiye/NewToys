using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.VideoTools.ViewModels;

/// <summary>
/// 格式转码 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class TranscodeViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "格式转码";
    [ObservableProperty] private string _pageIcon = "🔄";
    [ObservableProperty] private string _pageDescription = "视频格式批量转码（MP4/MKV/MOV/WebM 等）。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
