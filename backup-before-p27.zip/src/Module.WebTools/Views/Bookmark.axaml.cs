using Avalonia.Controls;

namespace NewToys.Module.WebTools.Views;

public partial class Bookmark : UserControl
{
    public Bookmark()
    {
        InitializeComponent();
    }
}
