using NewToys.Shared.Models;
using System.Collections.ObjectModel;

namespace NewToys.Shared.Services;

public interface IMenuService
{
    ObservableCollection<MenuGroup> Groups { get; }
    MenuGroup AddGroup(string key, string title, string icon = "📁", int order = 100, bool isHome = false);
    void AddItem(string groupKey, MenuItem item);
}
