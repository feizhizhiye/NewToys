using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.VideoTools.ViewModels;

/// <summary>
/// 视频库 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class VideoListViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "视频库";
    [ObservableProperty] private string _pageIcon = "🎞";
    [ObservableProperty] private string _pageDescription = "本地视频库管理，按目录扫描、预览、快速打开。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
