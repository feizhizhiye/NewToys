using Microsoft.Extensions.DependencyInjection;
using NewToys.Module.PcTools.ViewModels;
using NewToys.Shared.Models;
using NewToys.Shared.Services;

namespace NewToys.Module.PcTools;

public class PcToolsModule : IModule
{
    public void RegisterServices(IServiceCollection services)
    {
        services.AddTransient<PcHomeViewModel>();
        services.AddTransient<QuickSettingsViewModel>();
        services.AddTransient<MyShortcutsViewModel>();
        services.AddTransient<FavoritesViewModel>();
        services.AddTransient<PcInfoViewModel>();
        services.AddTransient<WingetViewModel>();
    }

    public void Initialize(IServiceProvider services)
    {
        var menu = services.GetRequiredService<IMenuService>();
        var group = menu.AddGroup("pc", "PC工具箱", "🖥", order: 10);
        menu.AddItem("pc", new MenuItem { Key = "pc-home", Title = "工具箱首页", ViewModelType = typeof(PcHomeViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("pc", new MenuItem { Key = "pc-quick", Title = "快捷设置", ViewModelType = typeof(QuickSettingsViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("pc", new MenuItem { Key = "pc-shortcuts", Title = "我的快捷方式", ViewModelType = typeof(MyShortcutsViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("pc", new MenuItem { Key = "pc-favorites", Title = "收藏夹", ViewModelType = typeof(FavoritesViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("pc", new MenuItem { Key = "pc-info", Title = "系统信息", ViewModelType = typeof(PcInfoViewModel).AssemblyQualifiedName ?? "" });
        menu.AddItem("pc", new MenuItem { Key = "pc-winget", Title = "软件包管理", ViewModelType = typeof(WingetViewModel).AssemblyQualifiedName ?? "" });
    }
}
