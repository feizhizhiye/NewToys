using Avalonia.Controls;

namespace NewToys.Module.WebTools.Views;

public partial class WebHttp : UserControl
{
    public WebHttp()
    {
        InitializeComponent();
    }
}
