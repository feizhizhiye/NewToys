param(
    [switch]$Deep,
    [switch]$Data,
    [switch]$All
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptDir

Write-Host "==> 清理构建产物..." -ForegroundColor Cyan

Push-Location (Join-Path $RepoRoot "src")
try {
    dotnet clean
}
finally {
    Pop-Location
}

if ($Deep -or $All) {
    Write-Host "==> 深度清理所有 bin/obj/artifacts..." -ForegroundColor Cyan
    $pathsToRemove = @(
        (Join-Path $RepoRoot "artifacts"),
        (Join-Path $RepoRoot "production")
    )
    # 递归删除所有bin/obj
    Get-ChildItem $RepoRoot -Directory -Recurse -Include bin, obj | ForEach-Object {
        $pathsToRemove += $_.FullName
    }
    foreach ($path in $pathsToRemove) {
        if (Test-Path $path) {
            Remove-Item $path -Recurse -Force
            Write-Host "  删除: $path" -ForegroundColor Gray
        }
    }
}

if ($Data -or $All) {
    Write-Host "==> 清理用户数据..." -ForegroundColor Cyan
    $varDir = Join-Path $RepoRoot "var"
    @("logs", "cache", "temp") | ForEach-Object {
        $path = Join-Path $varDir $_
        if (Test-Path $path) {
            Remove-Item $path -Recurse -Force
            Write-Host "  删除: $path" -ForegroundColor Gray
        }
    }
}

# 清理根目录残留的Modules
$rootModules = Join-Path $RepoRoot "Modules"
if (Test-Path $rootModules) {
    Remove-Item $rootModules -Recurse -Force
    Write-Host "  删除根目录残留Modules: $rootModules" -ForegroundColor Gray
}

Write-Host "`n✅ 清理完成" -ForegroundColor Green
