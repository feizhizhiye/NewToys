using Avalonia.Controls;

namespace NewToys.Module.Settings.Views;

public partial class ThemeView : UserControl
{
    public ThemeView()
    {
        InitializeComponent();
    }
}
