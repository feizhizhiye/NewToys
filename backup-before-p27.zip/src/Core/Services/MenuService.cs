using NewToys.Shared.Models;
using NewToys.Shared.Services;
using System.Collections.ObjectModel;
using System.Linq;

namespace NewToys.Core.Services;

public class MenuService : IMenuService
{
    public ObservableCollection<MenuGroup> Groups { get; } = new();

    public MenuService()
    {
        // 内置首页（永远最先注册）
        AddGroup("home", "首页", "🏠", order: 0, isHome: true);
    }

    public MenuGroup AddGroup(string key, string title, string icon = "📁", int order = 100, bool isHome = false)
    {
        var existing = Groups.FirstOrDefault(g => g.Key == key);
        if (existing != null) return existing;

        var group = new MenuGroup { Key = key, Title = title, Icon = icon, Order = order, IsHome = isHome };
        Groups.Add(group);

        // 保持Groups按Order排序
        var sorted = Groups.OrderBy(g => g.Order).ToList();
        Groups.Clear();
        foreach (var g in sorted) Groups.Add(g);

        return group;
    }

    public void AddItem(string groupKey, MenuItem item)
    {
        var group = Groups.FirstOrDefault(g => g.Key == groupKey);
        if (group == null) return;
        if (!group.Items.Any(i => i.Key == item.Key))
        {
            group.Items.Add(item);
        }
    }
}
