using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.Extensions.DependencyInjection;
using NewToys.Shared.Models;
using NewToys.Shared.Services;
using NewToys.Shell.ViewModels;
using NewToys.Shell.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using MenuItem = NewToys.Shared.Models.MenuItem;

namespace NewToys.Shell.Services;

public class NavigationService : INavigationService
{
    private readonly IServiceProvider _services;
    private readonly IMenuService _menuService;
    private readonly Dictionary<string, Func<Control>> _viewFactories = new();
    private Control? _currentView;
    private string? _currentKey;
    private string? _currentTitle;

    public event EventHandler<string>? Navigated;

    object? INavigationService.CurrentView => _currentView;
    public Control? CurrentView => _currentView;
    public string? CurrentPageKey => _currentKey;
    public string? CurrentPageTitle => _currentTitle;

    public NavigationService(IServiceProvider services, IMenuService menuService)
    {
        _services = services;
        _menuService = menuService;
    }

    public void RegisterView<TViewModel, TView>()
        where TViewModel : ObservableObject
        where TView : Control, new()
    {
        var key = typeof(TViewModel).FullName!;
        _viewFactories[key] = () => new TView();
    }

    public void RegisterViewsFromAssembly(Assembly asm)
    {
        var viewTypes = asm.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.Name.EndsWith("View") && typeof(Control).IsAssignableFrom(t))
            .ToList();

        foreach (var viewType in viewTypes)
        {
            // 自动匹配 XxxView ↔ XxxViewModel
            var vmName = viewType.FullName!.Replace(".Views.", ".ViewModels.") + "Model";
            var vmType = asm.GetType(vmName);
            if (vmType == null) continue;

            _viewFactories[vmType.FullName!] = () =>
            {
                try
                {
                    var control = (Control?)Activator.CreateInstance(viewType);
                    if (control == null) return BuildPlaceholderView("视图创建失败", "");
                    try
                    {
                        var vm = _services.GetService(vmType);
                        if (vm != null) control.DataContext = vm;
                    }
                    catch { }
                    return control;
                }
                catch (Exception ex)
                {
                    return BuildErrorView($"创建视图失败: {ex.Message}");
                }
            };
        }
    }

    public void NavigateTo(string key)
    {
        try
        {
            if (string.IsNullOrEmpty(key)) return;

            // 首页特殊处理
            if (key == "home")
            {
                var homeVm = _services.GetService<HomeViewModel>();
                var homeView = new HomeView { DataContext = homeVm };
                _currentView = homeView;
                _currentKey = key;
                _currentTitle = "首页";
                Navigated?.Invoke(this, key);
                return;
            }

            // 找菜单
            var menuItem = FindMenuItem(key);
            if (menuItem == null || string.IsNullOrEmpty(menuItem.ViewModelType))
            {
                _currentView = BuildErrorView($"页面未找到: {key}");
                _currentKey = key;
                _currentTitle = key;
                Navigated?.Invoke(this, key);
                return;
            }

            var vmType = Type.GetType(menuItem.ViewModelType);
            if (vmType == null)
            {
                // 尝试所有已加载程序集搜索
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    vmType = asm.GetType(menuItem.ViewModelType);
                    if (vmType != null) break;
                }
            }
            if (vmType == null)
            {
                // 该页面的真实 ViewModel 还没实现（或所在程序集未加载）→ 优雅回退到占位页，
                // 不弹红色错误页；后续补上 XxxViewModel + XxxView 后自动生效
                _currentView = BuildPlaceholderView(menuItem.Title, "该页面尚未实现，敬请期待");
                _currentKey = key;
                _currentTitle = menuItem.Title;
                Navigated?.Invoke(this, key);
                return;
            }

            // 构造View
            Control? view = null;
            if (_viewFactories.TryGetValue(vmType.FullName!, out var factory))
            {
                view = factory();
            }

            // 兜底：无XxxView则返回占位页
            if (view == null)
            {
                view = BuildPlaceholderView(menuItem.Title, $"功能模块「{menuItem.Title}」正在开发中");
            }

            // 注入ViewModel（如果是占位页也绑PlaceholderVM）
            try
            {
                object? vm = null;
                try { vm = _services.GetService(vmType); } catch { }
                if (vm != null) view.DataContext = vm;
            }
            catch { }

            _currentView = view;
            _currentKey = key;
            _currentTitle = menuItem.Title;
            Navigated?.Invoke(this, key);
        }
        catch (Exception ex)
        {
            _currentView = BuildErrorView($"导航失败: {ex.Message}");
            _currentKey = key;
            _currentTitle = "错误";
            try { Navigated?.Invoke(this, key ?? "error"); } catch { }
        }
    }

    private MenuItem? FindMenuItem(string key)
    {
        foreach (var group in _menuService.Groups)
        {
            if (group.Key == key) return group.Items?.FirstOrDefault();
            var item = group.Items?.FirstOrDefault(i => i.Key == key);
            if (item != null) return item;
        }
        return null;
    }

    private Control BuildPlaceholderView(string title, string desc)
    {
        return new PlaceholderView
        {
            DataContext = new PlaceholderViewModel
            {
                Title = title,
                Description = desc
            }
        };
    }

    private Control BuildErrorView(string msg)
    {
        IBrush? Brush(string k) => Application.Current?.TryFindResource(k, out var r) == true && r is IBrush b ? b : null;
        var title = new TextBlock
        {
            Text = "⚠️ 页面加载失败",
            FontSize = 20,
            FontWeight = FontWeight.Bold,
            Foreground = Brush("TextPrimary") ?? Brushes.Black,
        };
        var body = new TextBlock
        {
            Text = msg,
            TextWrapping = TextWrapping.Wrap,
            Foreground = Brush("TextSecondary") ?? Brushes.Gray,
        };
        return new Border
        {
            Margin = new Thickness(40),
            Child = new StackPanel
            {
                Spacing = 12,
                Children = { title, body }
            }
        };
    }
}
