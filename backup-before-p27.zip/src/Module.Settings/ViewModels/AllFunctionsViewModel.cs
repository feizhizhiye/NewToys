using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.Settings.ViewModels;

/// <summary>
/// 功能清单 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class AllFunctionsViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "功能清单";
    [ObservableProperty] private string _pageIcon = "📋";
    [ObservableProperty] private string _pageDescription = "NewToys 全部功能清单与启用状态。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
