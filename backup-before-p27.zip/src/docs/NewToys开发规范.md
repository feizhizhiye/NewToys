# NewToys 开发规范

> 版本：v1.12 ｜ 适用工程：NewToys（Avalonia 12 + CommunityToolkit.Mvvm + .NET 10）
> 本文件是 NewToys 项目的最高技术约束。一切代码、文档、脚本改动都必须符合本规范。
> AI 协作时，动代码之前必须先完整阅读本文件。

---

## 目录

- [0. 文档体系](#0-文档体系)
- [1. 项目概述](#1-项目概述)
- [2. 技术栈](#2-技术栈)
- [3. UI 风格规范](#3-ui-风格规范)
- [4. 代码组织结构](#4-代码组织结构)
- [5. 编码规范](#5-编码规范)
- [6. 模块开发规范](#6-模块开发规范)
- [7. 构建、运行与产物约定](#7-构建运行与产物约定)
- [8. 启动与导航规范](#8-启动与导航规范)
- [9. Git 与版本管理](#9-git-与版本管理)
- [10. 交付与协作规范](#10-交付与协作规范)
- [11. AI 强制约束清单（硬约束速查）](#11-ai-强制约束清单硬约束速查)
- [12. 经验教训](#12-经验教训)
- [13. 工程结构与运行环境约束](#13-工程结构与运行环境约束)
- [14. 源码快照导出/导入](#14-源码快照导出导入)
- [15. 标准工作流（日常闭环）](#15-标准工作流日常闭环)
- [附录 A. 常见坑对照表](#附录-a-常见坑对照表)

---

## 0. 文档体系

`src/docs/` 下共维护 **3 份文档**（v1.12 起由 5 份合并而来），各司其职，改动代码 / 文档时保持同步：

| 文件 | 作用 | 何时更新 |
|---|---|---|
| `NewToys开发规范.md`（本文件） | **技术宪法**：做什么、怎么做；含全部硬约束速查（第 11 章） | 架构 / 约定 / 规则变化时 |
| `NewToys-项目现状与进度.md` | **台账**：当前基线、已完成、待办、关键文件索引 | 每次交付后 |
| `NewToys-AI协作提示词.md` | **会话启动包**：提示词模板 + 交付自检清单（附录 A） | 协作流程 / 交付规则变化时 |

> ⚠️ **这 3 份文件是本项目的"宪法"，一律不得删除、移动或改名**；任何补丁都必须保证它们完整保留。

### 0.1 文档职责矩阵与单一权威原则

各文档分工如下，**同一条规则只在"权威处"定义一次**，其余文档只引用、不重述：

| 文档 | 唯一权威内容 |
|---|---|
| `NewToys开发规范.md`（本文件） | 技术标准、架构、UI、编码、启动导航、工程结构、**必须 / 禁止清单**（第 11 章）、经验教训 |
| `NewToys-项目现状与进度.md` | 当前基线、已完成、待办、关键文件索引（**台账，每次交付后回写**） |
| `NewToys-AI协作提示词.md` | 每次会话开头**粘贴的模板** + 交付门禁清单（附录 A） |

**单一权威原则（Single Authoritative Source）**：改规则时**只改权威处**，其他文档同步"引用"而非"复制"内容，避免"改一处、漏三处"的漂移。

### 0.2 文档合并记录（方案 A，v1.12 已执行）

> v1.11 及以前为 **5 份**；v1.12 起合并为 **3 份**，重叠内容**无损归并**（内容全部保留，仅移位）。

| 合并前（5 份） | 归并去向 |
|---|---|
| `NewToys开发规范.md` | 保留，仍为技术宪法 |
| `NewToys开发约束提示词.md` | **并入本文件第 11 章**（分主题速查 + 必须 / 禁止总清单） |
| `NewToys-交付自检清单.md` | **并入 `NewToys-AI协作提示词.md` 附录 A**（交付门禁，完整可打勾版） |
| `NewToys-项目现状与进度.md` | 保留，仍为台账 |
| `NewToys-AI协作提示词.md` | 保留，升格为"会话启动包" |

- **收益**：每次改动只需同步 **2–3 份**，且规则只在权威处定义一次。
- **代价**：单份文档变大；交叉引用统一指向新位置（原《约束提示词》→ 规范第 11 章；原《交付自检清单》→ AI 协作提示词附录 A）。

---

## 1. 项目概述

### 1.1 定位

**NewToys 是作者个人自制的工具集**，用于满足自己高强度使用电脑过程中的各类高频需求。

- **非商业、非通用产品**：不做面向大众的产品化包装，**"自用顺手"是第一优先级**。
- **围绕真实高频场景**：批量启动、快捷键、网址管理、视频处理、系统配置等。
- **可长期演进**：功能会持续增补，因此架构必须支持"随时加功能、随时停功能"。

### 1.2 目标平台

| 项 | 现状 | 说明 |
|---|---|---|
| 主平台 | **Windows 10 LTSC** | 当前交付与调试目标 |
| 迁移方向 | **Debian 13**（后期可能） | 架构需预留跨平台能力 |
| 本地工具链 | **pwsh 7.6 / python3 / ffmpeg 9** | 脚本与外部依赖以这些为准 |

### 1.3 设计取向

1. **模块化**：功能按模块拆分，可独立开发、独立启停。
2. **插件化**：模块编译为独立 DLL，运行时装配，新增模块不改宿主。
3. **轻量务实**：工具类应用，UI 不追求炫技，重效率与稳定。
4. **自控**：**不引入任何第三方 UI 库，全局控件自己写**。

### 1.4 一级功能域

- **首页**（常用 / 收藏，特殊：无二级菜单）
- **PC 工具箱**
- **Web 工具箱**
- **视频工具箱**
- **系统设置**（固定在最底部）

---

## 2. 技术栈

### 2.1 锁定版本

版本一律集中在 `src/Directory.Packages.props` 声明（中央包管理）。

| 类别 | 包 / 组件 | 版本 | 说明 |
|---|---|---|---|
| 运行时 | .NET | **10（net10.0）** | `global.json` 锁 SDK，`rollForward: latestMinor` |
| UI 框架 | Avalonia | **12.1.3** | `Avalonia` / `Avalonia.Desktop` / `Avalonia.Themes.Fluent` / `Avalonia.Fonts.Inter` |
| MVVM | CommunityToolkit.Mvvm | **8.4.2** | 源生成器 `[ObservableProperty]` / `[RelayCommand]` |
| DI | Microsoft.Extensions.DependencyInjection | **9.0.0** | 含 `Abstractions` |
| 包管理 | 中央包版本管理 | — | `ManagePackageVersionsCentrally=true` |

预留但暂未使用的微软扩展包（Configuration / Logging / Options 系列，均 9.0.0）已统一声明，避免后续出现 `NU1010`。

### 2.2 硬规则

- **版本只写在 `Directory.Packages.props`**，`csproj` 里只写 `<PackageReference Include="Xxx" />`，**禁止写 `Version`**（否则 `NU1010`）。
- **禁止引入任何第三方 UI 组件库**（如 Material.Avalonia、SukiUI、FluentAvalonia、Semi.Avalonia 等）。需要什么控件/样式，**自己写**。
- Avalonia 采用**最新稳定版**；升级时全局修改 `Directory.Packages.props` 中的版本号。
- 语言设置：`LangVersion=latest`、`Nullable=enable`、`ImplicitUsings=enable`。
- 全局启用编译绑定：`AvaloniaUseCompiledBindingsByDefault=true`。

---

## 3. UI 风格规范

### 3.1 整体布局：三栏仿微信 PC 版

```
┌─ 自定义标题栏 40px（随主题变色，右侧最小化/最大化/关闭）────────────┐
│ NewToys                                        _  □  ×          │
├──66px──┬──260px────┬─────────────────────────────────────────────┤
│ 🟢 N   │ 面板标题   │ 页面标题                                    │
├────────┼───────────┼─────────────────────────────────────────────┤
│  🖥 🌐 🎬 │          │                                             │
│  模块图标│ 二级菜单   │           内容区                            │
│  （滚动）│ （列表）   │                                             │
│────────│           │                                             │
│  🏠 ⚙  │           │  ──────────────────────────────────────     │
│ 底部Dock │           │  底部状态栏 32px                            │
└────────┴───────────┴─────────────────────────────────────────────┘
```

| 列 | 宽度 | 内容 |
|---|---|---|
| 第一列 | **66px** | 深色主菜单：顶部圆形 Logo；中部功能模块图标（滚动）；底部 Dock |
| 第二列 | **260px** | 二级菜单面板（头部 56px + 列表） |
| 第三列 | **自适应 `*`** | 内容区（头部 56px + 内容 + 底部状态栏 32px） |

### 3.2 关键例外规则（务必遵守）

- **首页模式隐藏第二列**：点 🏠 时列定义切换为 `66,*`（第二列宽 0 且 `IsVisible=false`），呈**两栏**全宽内容；点功能模块时切回 `66,260,*` 三栏。
- **首页不显示二级菜单**：首页是"常用 / 收藏"页，第二列不出现菜单列表。
- **⚙ 系统设置固定在第一列最底部**（分组 `Order=999`），上面是 🏠 首页按钮。

### 3.3 尺寸清单

| 元素 | 尺寸 |
|---|---|
| 标题栏 | 40px；窗口按钮 46×40 |
| 第一列 | 宽 66px；Logo 36×36 圆形；图标按钮高 44px |
| 第二列 | 宽 260px；面板头部 56px；列表项高 44px |
| 第三列 | 头部 56px；底部状态栏 32px；内容边距 24px |
| 卡片 | 圆角 8px；按钮圆角 6px；选中指示条宽 3px |
| 主窗口 | 1200×780；最小 900×600；居中启动 |

### 3.4 颜色规范

浅色主题基准：

| 元素 | 颜色 |
|---|---|
| 第一列背景（明暗一致） | `#2E2E2E` |
| 选中指示条 / 强调色（微信绿） | `#07C160` |
| 第一列图标：未选中 / 选中 | `#B7B7B7` / `White` |
| 二级菜单选中底色 | `#D9EDDF` |
| 其余（背景/文字/边框/卡片等） | **走主题资源 `DynamicResource`，禁止硬编码** |

### 3.5 主题规范

- 两套主题：**Light / Dark**，通过 `IThemeService` 切换，持久化到 `var/config/theme.json`。
- 主题资源**纯代码构建** `ResourceDictionary` 注入 `Application.Resources.MergedDictionaries`，并设置 `RequestedThemeVariant`。
  > ⚠️ **禁止**用"独立 `.axaml` 资源字典 + `AvaloniaXamlLoader.Load(uri)`"的方式加载主题：Avalonia 12 默认预编译 XAML，会抛 `No precompiled XAML found`。
- 主题资源键（`DynamicResource`）：

  `AppBackground`、`TitleBarBackground`、`TitleBarText`、`SidePanelBackground`、`PanelHeaderBackground`、`ContentBackground`、`ContentHeaderBackground`、`StatusBarBackground`、`BorderColor`、`TextPrimary`、`TextSecondary`、`HoverBackground`、`CardBackground`

- **除第一列侧栏外**，所有颜色必须绑 `DynamicResource`，切主题时全窗口实时生效。
- 交互遵循微信习惯：hover 浅灰、选中绿底、卡片圆角、按钮圆角。

---

## 4. 代码组织结构

### 4.1 分层与依赖方向（单向，严禁反向）

```
        Shared   ── 契约与模型，【不引用任何 UI 框架】
          ▲
        Core     ── 核心服务（菜单/主题/模块加载/配置），【不引用 Avalonia】
          ▲
        Shell    ── 宿主（App/主窗/导航/DI/ViewLocator），引用 Avalonia
          ▲
       Module.*  ── 功能模块，仅引用 Shared（+ Core）
```

硬规则：

- `Shared` **不引用 Avalonia**；`Core` **不引用 Avalonia**（保持可被非 UI 场景复用）。
- **模块禁止 `using NewToys.Shell.*`**（Shell 引用所有模块，反向引用会构成循环依赖，直接编译失败）。
- **模块之间禁止互相引用**；跨模块协作一律通过 `Shared` 中的接口 / 契约。
- 全局控件、Shell 级样式放 `Shell`；公共基类 / 契约放 `Shared`。

#### 4.1.1 框架层冻结约定（重要）

`Shared` / `Core` / `Shell` 三层是**框架层**，在骨架稳定后进入**冻结状态**：

- 框架层只承载：分层骨架、DI 容器、模块加载、菜单 / 导航 / 主题等服务、主窗口与全局控件、契约与基类。
- **框架层代码一旦稳定，默认不再改动**；后续功能演进**只发生在 `Module.*` 内部**。
- 模块页面、功能逻辑、数据模型一律放各自模块，**不得为了"顺手"往 `Shell` / `Core` / `Shared` 里加东西**。
- 确需改框架层（新增全局服务、新增契约、调整全局布局等）时，**必须先取得用户明确同意**，并在文档与补丁中作为独立议题说明。
- 理由：框架层是所有模块的地基，频繁改动会牵动全部模块、放大回归风险，也违背"模块可独立开发 / 启停"的设计目标。

> 记忆点：**框架定，模块活。** 加功能去 `Module.*`，不要动 `Shell` / `Core` / `Shared`。

### 4.2 目录结构

```
src/
├── Directory.Build.props         # 统一 TargetFramework / 输出路径 / 编译绑定
├── Directory.Packages.props      # 中央包版本管理（唯一版本来源）
├── NewToys.slnx                  # 解决方案
├── docs/                         # 规范文档（4 份，勿删）
├── Shared/                       # 契约层：Models + Services（接口）
│   ├── Models/                   # IModule / MenuModels / ViewModelBase / LaunchConfig
│   └── Services/                 # IMenuService / INavigationService / IThemeService
├── Core/                         # 服务层（不引 Avalonia）
│   └── Services/                 # MenuService / ThemeService / ModuleLoader / AppConfigService
├── Shell/                        # 宿主
│   ├── App.axaml(.cs)            # 启动入口、DI、启动时序
│   ├── Program.cs
│   ├── Services/                 # NavigationService
│   ├── ViewModels/               # ShellViewModel / HomeViewModel / PlaceholderViewModel
│   ├── Views/                    # ShellView / HomeView / PlaceholderView / ErrorView
│   └── Converters/               # BoolInversionConverter
├── Module.PcTools/
├── Module.WebTools/
├── Module.VideoTools/
└── Module.Settings/
```

### 4.3 模块内部结构（按需创建，不用不建）

```
Module.Xxx/
├── Module.Xxx.csproj
├── XxxModule.cs                  # IModule 实现（注册服务 + 注册菜单）
├── Models/
├── Services/
├── ViewModels/
├── Views/                        # XxxView.axaml + .axaml.cs
├── Behaviors/                    # 可选
├── Converters/                   # 可选
├── Resources/                    # 可选
└── Common/                       # 可选
```

- **命名空间与目录一致**：如 `NewToys.Module.PcTools.ViewModels`、`NewToys.Module.Settings.Views`。
- 各项目 `RootNamespace` 固定为 `NewToys.<层名>` / `NewToys.Module.<模块名>`。

### 4.4 项目命名约定（**以现有工程为准**）

> 下表取自**当前 Avalonia 工程的实际配置**，是权威依据。
> 说明：作者曾提供一份 **WPF 版** NewToys 的同名对照表作为参考，其模块 `RootNamespace` 为 `NewToys.<模块名>`（无 `.Module` 段）。**本项目不沿用该写法**，一律以现有工程的实际配置为准。

| src 目录 | AssemblyName | RootNamespace | 说明 |
|---|---|---|---|
| `Shared/` | `Shared` | `NewToys.Shared` | 契约层：模型 + 接口 |
| `Core/` | `Core` | `NewToys.Core` | 服务实现层 |
| `Shell/` | `NewToys` | `NewToys.Shell` | 外壳；`AssemblyName` 显式设为 `NewToys`，让产物名为 `NewToys.exe` |
| `Module.Settings/` | `Module.Settings` | `NewToys.Module.Settings` | 系统设置模块 |
| `Module.PcTools/` | `Module.PcTools` | `NewToys.Module.PcTools` | PC 工具箱模块 |
| `Module.WebTools/` | `Module.WebTools` | `NewToys.Module.WebTools` | Web 工具箱模块 |
| `Module.VideoTools/` | `Module.VideoTools` | `NewToys.Module.VideoTools` | 视频工具箱模块 |

规则：

- 模块 `RootNamespace` 统一为 `NewToys.Module.<模块名>`；**不要**写成 `NewToys.<模块名>`。
- **`AssemblyName` 除 `Shell` 外均取默认值（= 项目 / 目录名）**：`Shared`、`Core`、`Module.Settings`、`Module.PcTools`、`Module.WebTools`、`Module.VideoTools`。
- 因此 **`AssemblyName` 与 `RootNamespace` 普遍不同**（例如 `Core` vs `NewToys.Core`）属**正常现象**，**勿强行"统一"**（那属于框架层改动，需用户同意，见 4.1.1）。
- 只有 `Shell` 显式设了 `AssemblyName = NewToys`，让产物名为 `NewToys.exe`。
- 框架层（`Shared` / `Core` / `Shell`）命名已成既定事实，**不再调整**（见 4.1.1）。

### 4.5 各模块功能清单

> 本节是**功能参考清单**，功能来源：作者原有的 **WPF 版** NewToys 工程（**仅作功能参考，目录结构与命名不照搬**）。
> Avalonia 版按 4.2 / 4.3 的**现有结构**落地；路由 Key 以各模块 `XxxModule.cs` 实际注册为准（见 4.5.6）。

#### 4.5.1 首页（Shell 内置 · 特殊页）

- 定位：**常用 / 收藏页**，无二级菜单，两栏全宽。
- 功能：常用功能收藏（可固定 / 取消固定）；三个一键操作（批量打开网址 ×2 套浏览器配置、批量打开软件）；快捷跳转系统设置。
- 参考：WPF `Shell/Views/HomeView.xaml`。

#### 4.5.2 PC 工具箱（`Module.PcTools`）

- 定位：PC 日常维护与快捷操作。
- 参考源码（WPF）：
  - Models：`QuickAction`、`WingetPackage`、`WingetSource`
  - Services：`QuickActionRunner`、`QuickActionStore`、`SystemSettingCatalog`、`WingetService`
  - ViewModels：`FavoritesViewModel`、`MyShortcutsViewModel`、`WingetViewModel`
  - Views：`PcHomeView`、`PcInfoView`、`QuickSettingsView`、`MyShortcutsView`、`WingetView`

| Key | 标题 | 功能说明 |
|---|---|---|
| `pc-home` | 工具箱首页 | 模块入口 / 概览 |
| `pc-quick` | 快捷设置 | 系统快捷开关（`SystemSettingCatalog`） |
| `pc-shortcuts` | 我的快捷方式 | 快捷方式管理（`QuickAction` / `Store` / `Runner`） |
| `pc-favorites` | 收藏夹 | 收藏的快捷项 |
| `pc-info` | 系统信息 | 电脑信息采集与展示 |
| `pc-winget` | 软件包管理 | winget 包搜索 / 安装（`WingetService`） |

#### 4.5.3 Web 工具箱（`Module.WebTools`）

- 定位：网络与网页相关工具。
- 参考源码（WPF）：
  - Models：`Bookmark`、`PingTarget`、`ScrapeModels`
  - Services：`BookmarkChecker`、`BookmarkStore`、`BrowserBookmarkImporter`、`MiniHtml`、`PingService`、`PingStore`、`UrlScraper`
  - ViewModels：`BookmarkViewModel`、`PingViewModel`、`ScrapeViewModel`
  - Views：`WebHomeView`、`WebHttpView`、`BookmarkView`、`PingView`、`ScrapeView`

| Key | 标题 | 功能说明 |
|---|---|---|
| `web-home` | 工具箱首页 | 模块入口 |
| `web-http` | HTTP测试 | HTTP 请求调试 |
| `web-bookmark` | 书签管理 | 书签增删改查 / 导入（`BookmarkStore` / `Importer` / `Checker`） |
| `web-ping` | 网络Ping | 批量 ping（`PingService` / `PingStore`） |
| `web-scrape` | 网页抓取 | 网页内容抓取（`UrlScraper` / `MiniHtml`） |

#### 4.5.4 视频工具箱（`Module.VideoTools`）

- 定位：本地视频处理（依赖 **ffmpeg 9**）。
- 参考源码（WPF）：
  - Models：`Enums`、`FolderGroupInfo`、`MediaInfo`、`MediaJob`、`OptionItem`、`TagItem`、`VideoColumn`、`VideoItem`、`VideoQuery`
  - Services：`AppDataPaths`、`FfmpegService`、`FramePreviewService`、`VideoLibraryService`（接口 `IFfmpegService` / `IFramePreviewService` / `IVideoLibraryService`，模型 `ImportModels`）
  - ViewModels：`VideoViewModelBase`、`MediaQueueViewModelBase`、`VideoListViewModel`、`VideoCutViewModel`、`TranscodeViewModel`
  - Views：`VideoListView`、`VideoCutView`、`TranscodeView`
  - 其他：Behaviors `DataGridColumnsBehavior`、Common `TimeText`、Converters `TagColorBrushConverter`、Resources `VideoStyles.xaml`

| Key | 标题 | 功能说明 |
|---|---|---|
| `video-list` | 视频库 | 本地视频库浏览 / 管理 |
| `video-cut` | 视频剪辑 | 剪切片段 |
| `video-transcode` | 格式转码 | 转码（`FfmpegService`） |

#### 4.5.5 系统设置（`Module.Settings`）

- 定位：全局配置。
- 参考源码（WPF）：
  - Services：`AppDataBackup`
  - ViewModels：`AllFunctionsViewModel`
  - Views：`GeneralView`、`ThemeView`、`LaunchConfigView`、`PathView`、`DnsView`、`DataView`、`AllFunctionsView`、`AboutView`

| Key | 标题 | 功能说明 |
|---|---|---|
| `settings-theme` | 主题外观 | ✅ 已实现（明暗切换） |
| `settings-general` | 通用设置 | 通用选项 |
| `settings-launch` | 启动配置 | 开机启动 / 启动参数 |
| `settings-path` | 路径配置 | 目录配置 |
| `settings-dns` | 加密DNS | 加密 DNS 设置 |
| `settings-data` | 数据管理 | 备份 / 清理（`AppDataBackup`） |
| `settings-functions` | 功能清单 | 全部功能索引 |
| `settings-about` | 关于 | 版本信息 |

#### 4.5.6 路由 Key 权威来源

各模块菜单 Key 的**唯一权威**是各模块 `XxxModule.cs` 中 `menu.AddGroup` / `menu.AddItem` 的**实际注册**。本节表格应与之一致；若不一致，**以代码为准**并同步修正本节。

---

## 5. 编码规范

### 5.1 C# 规范

- 使用**文件作用域命名空间**（`namespace X;`）；`using` 置于文件顶部，`System.*` 优先。
- 命名：
  - 公共成员 / 类型 / 方法：`PascalCase`
  - 私有字段 / 局部变量 / 参数：`camelCase`（私有字段前缀 `_`）
  - 异步方法：以 `Async` 结尾
- **凡是带 `[ObservableProperty]` / `[RelayCommand]` 的类，必须声明为 `partial`**（CommunityToolkit.Mvvm 源生成器硬性要求，否则 `CS0260`）。
- 属性优先用 `[ObservableProperty]` 私有字段；命令用 `[RelayCommand]`。
- **构造注入**为主；`Ioc.Default` 仅在必要处使用（如 code-behind、回调、无法构造注入的场景），不要在业务类里到处服务定位。
- 公共 API 写 XML 注释；复杂逻辑写行内注释说明"为什么"。
- 集合属性用 `ObservableCollection<T>`（需通知 UI 时）。

### 5.2 XAML（.axaml）规范

- **扩展名必须为 `.axaml`**：Avalonia 12 **不再识别 `.xaml`**。
- **所有 `xmlns` 必须声明在根元素**：Avalonia 12 **不允许在内嵌 `DataTemplate` 等子元素里新声明 `xmlns`**。
- **强制编译绑定**：每个 View 根元素必须写 `x:DataType`（全局 `AvaloniaUseCompiledBindingsByDefault=true`）。
- **禁止 WPF 专有写法**（Avalonia 不支持，会报 `AVLN2000`）：
  - `ItemContainerStyle`
  - `<Style TargetType="...">`（应为 `<Style Selector="...">`）
  - `Border.HorizontalContentAlignment`
  - `RowDefinitions` 短标签写法（`<Auto/>` / `<Star/>`），应写成字符串 `RowDefinitions="Auto,*,Auto"`
- 颜色一律 `DynamicResource`；字号/圆角/间距遵循第 3 章。
- 界面文案一律**中文**。
- **XAML 与 code-behind 分离**；交互复杂的列表（如动态菜单、卡片）**在 code-behind 构建**，规避绑定踩坑。

### 5.3 跨平台与路径

- 一律用 `Path.Combine` 拼路径，**禁止硬编码 `\` 或 `/`**。
- 用户数据统一在 `var/`：`config` / `logs` / `cache` / `temp`。
- 平台相关能力（`winget`、`ms-settings:`、`ffmpeg` 等）**集中封装**，便于后续替换为 Debian 实现。

### 5.4 异常处理

- 导航、模块加载、主题应用等**边界处必须 `try-catch`，失败不崩溃**。
- 允许 `catch`，但不应吞掉关键异常而无任何反馈——至少写日志或用兜底 UI 呈现。
- **全局兜底**：`AppDomain.UnhandledException` / 启动异常捕获，崩溃时给出可读错误窗，而不是静默闪退。

### 5.5 编译纪律

- **交付前 Debug 与 Release 两个配置都必须编译通过，且 0 Error / 0 Warning。**

---

## 6. 模块开发规范

### 6.1 模块接口

```csharp
public interface IModule
{
    void RegisterServices(IServiceCollection services);
    void Initialize(IServiceProvider services);   // 在此注册菜单
}
```

- 模块类命名 `XxxModule`，命名空间 `NewToys.Module.<模块名>`。
- `RegisterServices` 里注册本模块服务；`Initialize` 里调用 `IMenuService` 注册菜单。

### 6.2 菜单注册规范

- 新建分组：`menu.AddGroup(key, title, icon, order, isHome)`。
- 新增页面项：`menu.AddItem(groupKey, new MenuItem { Key, Title, ViewModelType })`。
- **菜单 Key 命名**：`<模块缩写>-<页面名>`，全小写连字符，如 `pc-home`、`settings-theme`、`video-list`。
- **分组 Order 约定**：首页 `0`、PC `10`、Web `20`、视频 `30`、**系统设置 `999`（永远最底）**。新增分组必须显式给 `Order`，否则顺序随程序集加载顺序漂移。
- **首页**：`MenuGroup.IsHome=true`，由 `MenuService` 内置优先注册；第一列不显示首页图标（首页用第一列底部的 🏠 按钮触发）。

### 6.3 Debug / Release 分离加载（重点）

| 模式 | 加载方式 | 宿主引用 | 用途 |
|---|---|---|---|
| **Debug** | 显式类型清单（`typeof(XxxModule)`） | `Shell.csproj` 以 `Condition="'$(Configuration)'=='Debug'"` 引用模块项目 | 开发调试，支持断点/热重载 |
| **Release** | 扫描 exe 同级 `Modules/` 目录 DLL | Shell **不引用**模块项目 | 发布分发 |

- **Debug 必须用显式类型清单**，不能只靠 `AppDomain.GetAssemblies()` 扫描：Debug 下程序集是**延迟加载**的，纯扫描可能一个都扫不到，导致菜单为空。清单位置：`src/Shell/App.axaml.cs` 的 `#if DEBUG` 块。
- **注释某个模块（跳过编译+加载）需改两处**：
  1. `src/Shell/App.axaml.cs` → 注释 `typeof(XxxModule)` 那一行；
  2. `src/Shell/Shell.csproj` → 注释对应的 `<ProjectReference .../>`。
  两处同时注释，才既跳过编译、又跳过加载，显著缩短 Debug 启动时间。
- **模块 DLL 位置**：永远与 `NewToys.exe` 同级目录下的 `Modules/`（Debug/Release 各自隔离）。运行时不依赖工作目录，靠 `Assembly.GetExecutingAssembly().Location` 定位。

### 6.4 新增模块步骤

1. 建 `src/Module.Xxx/Module.Xxx.csproj`（引 `Shared`，需要核心服务再引 `Core`；如用 Avalonia 控件加 `Avalonia` 包）。
2. 写 `XxxModule.cs` 实现 `IModule`。
3. `src/NewToys.slnx` 加入该项目。
4. Debug 链路：`App.axaml.cs` 清单加 `typeof(XxxModule)`；`Shell.csproj` 加条件 `ProjectReference`。
5. 在 `Initialize` 里注册菜单分组与页面项。
6. 构建脚本会自动把模块 DLL 同步到 `Modules/`（无需手改脚本）。

### 6.5 页面开发与占位机制

- ViewModel 继承 `ViewModelBase`（`Shared/Models`）；View 用 `UserControl`，放各自模块的 `ViewModels/` 与 `Views/`。
- 导航按菜单项的 `ViewModelType`（程序集限定名）解析视图；**找不到时自动兜底返回占位页**。
- 因此可以**先注册菜单、后补页面**：未实现的页面显示"页面开发中"占位，补齐真实 VM+View 后自动生效，**无需改动 Shell / Core / Shared**。

---

## 7. 构建、运行与产物约定

### 7.1 脚本（PowerShell 7）

| 脚本 | 用法 | 说明 |
|---|---|---|
| `scripts/build.ps1` | `-Configuration Debug\|Release` | 还原 + 编译；并把模块 DLL 同步到 `Shell/<Config>/net10.0/Modules/` |
| `scripts/run.ps1` | `-Configuration` `-NoBuild` | 先构建再启动；自动找 `NewToys.exe`（Windows）或 `NewToys.dll`（Linux） |
| `scripts/clean.ps1` | — | 清理编译产物 |
| `scripts/publish.ps1` | `-Standalone` `-Runtime` `-Version` | 发布到 `production/` |

> 脚本用 `pwsh`（PowerShell 7）执行，不是 Windows 自带的 `powershell.exe`（5.1）。

### 7.2 产物路径

| 产物 | 路径 |
|---|---|
| 编译输出 | `artifacts/bin/<项目名>/<Config>/net10.0/` |
| 主程序 | `artifacts/bin/Shell/<Config>/net10.0/NewToys.exe`（Windows）/ `NewToys.dll`（Linux） |
| 模块 DLL | `artifacts/bin/Shell/<Config>/net10.0/Modules/` |
| 发布产物 | `production/` |
| 用户数据 | `var/{config,logs,cache,temp}` |

### 7.3 源码纯净原则

- **`src/` 只放源码**；一切生成物放 `artifacts` / `production` / `Modules` / `var`（均被 `.gitignore` 忽略）。
- 根目录**不再**出现 `Modules/`（仅在生成物目录内）。

---

## 8. 启动与导航规范

### 8.1 启动时序（`App.OnFrameworkInitializationCompleted`）

```
1) 建 DI 容器：注册 IMenuService / IThemeService / INavigationService / ShellViewModel / HomeViewModel
2) 加载模块（Debug 清单 / Release 扫描）→ RegisterServices → AddSingleton<IModule>
3) BuildServiceProvider
4) 对每个模块 Initialize（注册菜单）
5) 应用主题（读 var/config/theme.json）
6) 构建主窗口 ShellView
7) 最后触发首次导航（首页）
```

### 8.2 防闪退铁律

1. **禁止在 ViewModel 构造函数中调用导航**。此时模块菜单可能尚未注册完成，会找不到目标 → 启动闪退。**首次导航必须由 App 在第 7 步触发**。
2. `NavigationService.NavigateTo` **找不到 key 不得抛异常**，应返回占位页。
3. 视图解析**必须返回非 null 的 `Control`**；异常时返回错误提示控件，`ContentControl` 永不因 null 崩溃。
4. 一级/二级菜单点击**必须写回导航服务**（`SelectedGroup` / `SelectedItem` 变更 → 触发导航）；双向绑定处加 `_isSyncing` 标志位**防止死循环**。
5. 首页/模块切换要同步更新第一列选中态与第二列可见性；切到首页时清除主菜单高亮残留。

---

## 9. Git 与版本管理

- **仓库根 = 能看到 `src/` 的那一级**。
- `.gitignore` 已忽略：`artifacts/`、`production/`、`Modules/`、`var/`、`patches/`、`bin/`、`obj/` 等。
- **提交信息格式**：`<type>: <简述>`，`type ∈ {feat, fix, docs, refactor, chore, style}`。
  例：`fix: 修复主题加载崩溃`、`docs: 完善开发规范 v1.4`。
- 版本号：工程版本 `vX.Y`；文档版本在各文档头部维护。
- **补丁命名（v1.11 起简化）**：`p<NN>-<slug>.patch`——`NN` 为两位补丁序号（与文档中「补丁 N」一致，如 `16`），`slug` 为 ≤16 字符的小写 ASCII 短描述（可省略）。例：`p16-workflow.patch`。**不再使用**带日期长前缀的旧格式（`NewToys-src-20261009-…`）。
  - 目的：**用户可在 `git apply` 后用手直接打出文件名**。
  - 用户可自行重命名，**不影响 `git apply`**（补丁内容与文件名无关）。
- 增量更新一律走 **git 补丁**（见第 10 章），不整包替换。
- 日常协作的完整闭环见 **第 15 章「标准工作流」**。

---

## 10. 交付与协作规范

> 本章针对本项目**反复出现过的一类严重问题**——「补丁/源码已就绪」却**拿不到下载链接**——做系统性根治。
> **本章是硬性门禁：违反任一条即视为本次交付失败，必须补齐后重发。**

### 10.1 事故复盘：为什么总是"没有链接"

历史上多次出现「AI 说已生成补丁，用户却点不到、下不了」的情况。根因归为 6 类，逐条给出根治办法：

| # | 根因 | 具体表现 | 根治办法 |
|---|---|---|---|
| A | **声称即交付** | 只在正文写"补丁已生成 / 已就绪"，实际**没有真正把文件落盘** | 规则 1：**先落盘、后声明**（必须真实写入 + 命令确认存在） |
| B | **标签放置不规范** | 下载标签与正文文字、代码块、行内反引号**混排或同行**，或夹在句子中间 | 规则 2：标签**独立成行**，前后留空行 |
| C | **用文件名冒充链接** | 正文写 `` `xx.patch` `` 或用纯文本写文件名，或说"点上面的链接"却根本没有标签 | 规则 4：**禁止文件名冒充链接**，正文只说"见上方链接" |
| D | **文件名含全角/中文括号** | 形如 `xxx（补丁6基线）.patch`，全角括号/中文与 `.patch` 混排 | 规则 5：交付件文件名**纯 ASCII** |
| E | **无交付前自检** | 收尾前不核对"文件是否落盘、标签是否产出、是否独立成行" | 规则 7：**交付前自检门禁**，不通过不发 |
| F | **多补丁 / 基线不明** | 一次报多个补丁名、且未说明基线，用户不知用哪个、或 apply 失败 | 规则 8：**基线显式声明**，出补丁前先确认用户已应用哪些补丁 |
| G | **只留单通道，无兜底** | 只依赖下载链接；链接一旦在用户端渲染失败，就彻底拿不到补丁内容 | 规则 9：**二级兜底通道**（单独重发 → 仍不行则把补丁正文分片贴出） |
| H | **交接方式想当然** | 要求用户"上传 zip 快照"，而本环境**不接收压缩包**，协议不可执行 | 规则 10：**不用压缩包做载体**，交接走正文粘贴优先（见 13.5） |

### 10.2 交付硬规则（机械化执行）

**规则 1｜先落盘，后声明（双动作）**
- 补丁 / 源码包**必须先用写文件动作真实写入仓库根目录**，再用文件系统命令**确认文件存在及大小**。
- **禁止**在文件尚未落盘时声明"已生成"「已就绪」。

**规则 2｜下载标签独立成行**
- 交付链接一律写成 `<fileDownload>绝对路径</fileDownload>`，**独占一行**，前后各留一个空行。
- **禁止**与任何文字、列表、表格、引用块、代码块同行或嵌套其中。

**规则 3｜一个文件一个标签**
- 有几个交付物就写几个标签，各自紧跟其说明段落，**不合并、不省略**。

**规则 4｜正文不得用文件名冒充链接**
- 正文只写"下载见上方链接"；`git apply` 命令放在链接之后。
- **禁止**只用行内代码 / 纯文本写补丁文件名来充当"链接"。

**规则 5｜交付件文件名：短、纯 ASCII、可手打（v1.11 起简化）**
- 补丁文件名统一为 **`p<NN>-<slug>.patch`**：`NN` 为两位补丁序号（与文档中「补丁 N」一致，如 `16`）；`slug` 为 ≤16 字符的小写 ASCII 短描述（可省略）。
  - 例：`p16-workflow.patch`、`p17-home-quickfix.patch`。
- 目标：**用户能用一只手在 `git apply` 后直接敲出文件名**。
- **禁止**文件名含**全角括号、中文标点、空格**，以及 `NewToys-src-<日期>-…` 之类的长前缀（历史补丁 6–15 为旧格式，新补丁一律用新格式）。
- 用户可自行重命名，**不影响 `git apply`**。

**规则 6｜固定交付模板（四块齐全，顺序固定）**
1. **⬇ 下载链接**——置顶，`<fileDownload>` 独立成行，**排在所有说明之前**；
2. **变更清单**——新增 / 修改 / 删除逐条 + 一句话说明；
3. **应用步骤**——含**前置基线**说明 + `git apply` 命令；
4. **验证记录**——`git apply --check` 结果 + Debug / Release 编译结果。

**规则 7｜交付前自检（门禁）**
- 收尾前逐项核对交付自检清单（见 `NewToys-AI协作提示词.md` 附录 A），**任一项不通过就补齐后再交付**，不允许"先发再说"。

**规则 8｜基线显式声明**
- 每个补丁标注**前置基线**（在哪个补丁之上）。
- 出补丁前先确认用户**已应用哪些补丁**；生成后在**与用户一致的基线**上用 `git apply --check` 验证。

**规则 9｜二级兜底通道（链接失效时必走）**
- 若用户反馈"看不到 / 点不到链接"，**按顺序**执行：
  1. **单独重发**：该条回复**除下载标签外不放任何其它内容**（排除被同行文字 / 代码块吞掉）；
  2. **仍失败 → 贴正文**：把补丁**正文**用代码块**分片**贴出（diff 片段），用户本地**手动存为 `.patch`** 即可 `git apply`——补丁是纯文本，此通道**完全不依赖链接**；
  3. 贴正文时逐片标注**序号 / 总片数**，避免截断遗漏。
- **禁止**在用户已反馈"没有链接"后，仍重复原样发"见上方链接"。

**规则 10｜不使用压缩包做载体**
- **交付方向**：默认只给 `src` 内变更的 git 补丁，**不打整仓 zip**（用户明确要求除外）。
- **接收方向**：本环境**不接收 zip**，**不得要求用户上传压缩包**（见 13.5.1）。

### 10.3 交付前自检清单（收尾门禁）

> 完整可打勾版见 `NewToys-AI协作提示词.md` 附录 A。以下为关键七项，**每次交付逐项核对**：

1. ☐ 交付件**已真实落盘**，并用命令确认存在、大小正常。
2. ☐ 下载标签**独立成行**、前后有空行、未与文字/代码块同行。
3. ☐ 交付件文件名**为纯 ASCII**，无全角括号/中文标点/空格。
4. ☐ **变更清单**与实际补丁内容一致（新增/修改/删除无遗漏）。
5. ☐ `git apply --check` 在**用户真实基线**上通过。
6. ☐ **Debug + Release 均 0 Error / 0 Warning**。
7. ☐ `src/docs/` 规范文件**完整保留**，未删除、未移动。
8. ☐ 若用户曾反馈"没有链接"，本条回复是否已走**二级兜底通道**（单独重发 / 贴补丁正文）？
9. ☐ 交接材料是否**未涉及 zip**、且已**最小化**？

### 10.4 协作流程

读规范 → 摸底现状 → 明确需求边界 → 按规范编码 → 编译验证（Debug/Release 0/0）→ **落盘补丁并验证存在** → 交付（下载链接 + 变更清单 + 应用步骤 + 验证记录）。

### 10.5 基线管理

- 以用户本地 **HEAD 为基线**出补丁。
- **若 `git apply` 失败**：先看报错、问清用户**实际基线**，基于真实基线重出；**禁止盲目 `--3way` 或强推**。
- **一次只改一个主题、逐个 `git apply` 验证**，便于定位问题与回滚。
- 只交付 **`src/` 范围内**变更；**不改动 `src/` 以外的目录**（除非用户明确要求）。
- 规范 / 文档更新与代码更新**合并进同一补丁**。

---

## 11. AI 强制约束清单（硬约束速查）

> 本章由原独立文档《开发约束提示词》**并入**（v1.12 文档合并，方案 A）。
> 11.1 为**分主题速查**（只列"必须 / 禁止"，展开说明见各对应章节）；11.2 / 11.3 为**必须 / 禁止总清单**。

### 11.1 分主题速查

#### 11.1.1 布局约束（不可回退）

- ✅ 必须保持 **三栏仿微信 PC 布局**：第一列 66px 主菜单 ｜ 第二列 260px 二级菜单 ｜ 第三列自适应内容区。
- ✅ 首页（🏠）必须 **隐藏第二列**，呈两栏全宽（`66,*`）。
- ✅ 首页**不显示二级菜单**；它是"常用 / 收藏"页。
- ✅ **⚙ 系统设置固定在第一列最底部**（`Order=999`）。
- ✅ 必须保留**自定义标题栏**（40px，`WindowDecorations=None`，最小化/最大化/关闭）。
- ✅ 必须保留**明暗主题全局切换**（标题栏 / 二三列 / 卡片 / 文字 / 状态栏全部跟随）。
- ❌ 禁止改回顶部分组 Tab 或其它旧布局。
- ❌ 禁止用任何第三方 UI 库；全局控件自己写。

#### 11.1.2 架构约束

- ✅ 依赖方向单向：`Shared ← Core ← Shell ← Module.*`。
- ✅ 模块只引用 `Shared`（+ `Core`）。
- ✅ 公共基类 / 契约放 `Shared`；Shell 级控件 / 样式放 `Shell`。
- ✅ 新增菜单分组必须显式给 `Order`。
- ✅ **框架层冻结**：`Shared` / `Core` / `Shell` 稳定后默认不再改动，新功能只在 `Module.*` 内；确需改框架层须**先经用户同意**（见 4.1.1）。
- ✅ **按现有工程命名**：模块 `RootNamespace = NewToys.Module.<模块名>`、`AssemblyName = Module.<模块名>`；`Shell.AssemblyName = NewToys`（见 4.4）。
- ❌ 禁止无正当理由改动框架层（`Shared` / `Core` / `Shell`）。
- ❌ 禁止照搬 WPF 版工程的目录结构与命名（**功能可参考，结构与命名以本规范为准**）。
- ❌ 禁止模块 `using NewToys.Shell.*`（循环依赖）。
- ❌ 禁止模块之间互相引用。
- ❌ 禁止在 `csproj` 写包 `Version`（版本只在 `Directory.Packages.props`）。
- ❌ 禁止升级 / 降级技术栈版本（.NET 10 / Avalonia 12.1.3 / CT.Mvvm 8.4.2）。

#### 11.1.3 启动与导航约束（防闪退）

- ✅ 首次导航必须由 `App` 在**模块注册菜单完成之后**触发。
- ✅ `NavigateTo` 找不到 key 时返回占位页，不抛异常。
- ✅ 视图解析必须返回非 null `Control`（异常时返回错误控件）。
- ✅ 菜单点击必须写回导航服务，并加 `_isSyncing` 防双向绑定死循环。
- ❌ 禁止在 ViewModel 构造函数里调用导航。
- ❌ 禁止任何"找不到页面 / 视图"直接导致崩溃。

#### 11.1.4 编码约束

- ✅ 带 `[ObservableProperty]` / `[RelayCommand]` 的类必须 `partial`。
- ✅ XAML 文件用 `.axaml`；`xmlns` 全部声明在根元素；每个 View 根写 `x:DataType`。
- ✅ 颜色走 `DynamicResource`（第一列侧栏除外的硬编码色除外）。
- ✅ 路径用 `Path.Combine`；用户数据放 `var/`。
- ✅ 边界处 `try-catch`；关键异常不静默吞掉。
- ✅ 交付前 **Debug + Release 均 0 Error / 0 Warning**。
- ❌ 禁止 WPF 专有 XAML 写法（`ItemContainerStyle`、`Style TargetType`、`Border.HorizontalContentAlignment`、`<Auto/>` 短标签等）。
- ❌ 禁止用独立 axaml 资源字典 + `AvaloniaXamlLoader.Load` 加载主题。
- ❌ 禁止臆造用户未要求的功能。

#### 11.1.5 模块加载约束（Debug / Release 分离）

- ✅ **Debug**：`App.axaml.cs` 的 `#if DEBUG` 块内用**显式类型清单**（`typeof(XxxModule)`）；`Shell.csproj` 以 `Condition="'$(Configuration)'=='Debug'"` 引用模块项目。
- ✅ **Release**：Shell 不引用模块项目；运行时扫描 `NewToys.exe` 同级 `Modules/` 目录。
- ✅ 跳过某模块需**两处同时注释**：`App.axaml.cs` 的 `typeof(...)` + `Shell.csproj` 的 `ProjectReference`。
- ✅ 模块 DLL 永远与 `NewToys.exe` **同级**（`.../net10.0/Modules/`）。
- ❌ 禁止 Debug 下只靠 `AppDomain.GetAssemblies()` 扫描模块。

#### 11.1.6 交付约定（**头号反复事故区，最严**）

> 本项目反复出现"说给了链接、用户却拿不到"。以下每条都是硬门禁，**违反一条即交付失败**。完整门禁清单见 `NewToys-AI协作提示词.md` **附录 A**。

- ✅ **先落盘再声明**：补丁必须**真实写入**仓库根目录，并用命令**确认文件存在、大小正常**；**没落盘不许说"已生成"**。
- ✅ 只交付 `src/` 内变更，标准 git 补丁（路径形如 `src/...`）。
- ✅ **交付件文件名短且纯 ASCII**：`p<NN>-<slug>.patch`（NN=两位补丁序号，slug≤16 字符小写 ASCII，可省略），**便于手打 `git apply`**；禁止全角括号 / 中文标点 / 空格 / 日期长前缀。
- ✅ **必须给出补丁下载链接**：`<fileDownload>绝对路径</fileDownload>`，**独立成行、前后留空行**，且**排在回复最前面**。
- ✅ 有几个交付物就写**几个**标签（一个文件一个标签）。
- ✅ 附**变更清单**（新增 / 修改 / 删除 逐条 + 一句话）。
- ✅ 标注**前置基线**（本补丁在哪个补丁之上）；出补丁前确认用户**已应用哪些补丁**。
- ✅ 交付前用 `git apply --check` 在**用户真实基线**上验证通过。
- ✅ 规范更新与代码更新**合并进同一补丁**（用户明确只要 doc 除外）。
- ✅ 收尾前**逐项过**交付自检清单（`NewToys-AI协作提示词.md` 附录 A），全过才发。
- ✅ **二级兜底通道**：用户反馈"看不到链接"时，先**单独重发**下载标签；仍不行则把**补丁正文分片贴出**，用户手动存盘（补丁是纯文本，不依赖链接）。
- ✅ **交接免 zip**：要求用户提供的材料要**最小化**（3 份文档正文 + 基线声明 + 目标文件），**不得要求上传 zip / 整仓**。
- ✅ **源码快照机制**：用户上传 `framework.md` / `module-xxx.md` 续作时，必须按规范 14.4 流程处理；AI 返回源码变更时优先用 **sources md 快照格式**，git patch 作备选。
- ❌ 禁止输出整包 zip 替换（除非用户明确要求）。
- ❌ 禁止改动 `src/` 以外的目录（`scripts/` 协作脚本除外）。
- ❌ 禁止交付无法 `git apply` 的补丁。
- ❌ 禁止只口头说"补丁已就绪"而不给链接。
- ❌ 禁止把 `<fileDownload>` 与正文文字 / 代码块**写成同一行**。
- ❌ 禁止**只用文件名或路径冒充链接**（如正文写 `` `xx.patch` `` 当链接）。
- ❌ 禁止交付件文件名含**全角括号 / 中文标点 / 空格**，也不要用 `NewToys-src-<日期>-…` 长前缀。
- ❌ 禁止要求用户**上传 zip / 压缩包**（本环境不接收压缩包）。
- ❌ 禁止在用户反馈"没有链接"后仍只重复"见上方链接"，不走二级兜底通道。

#### 11.1.7 工程结构与真相源约束

> 详见规范 **第 13 章**。

- ✅ **唯一真相源 = 用户本地 git 仓库**；云端沙箱只是临时工作台（**随时会被重置**），成果必须以补丁回到本地。
- ✅ 源码只在 `src/`；生成物只在 `artifacts/` `Modules/` `var/` `production/`（均忽略）。
- ✅ 新增**顶层目录**须先在规范登记（第 13.2 表）。
- ✅ 交付件归档到 `patches/`；文件名**纯 ASCII**。
- ✅ 工作台角色目录：`NewToys/`（工作区）、`patches/`（归档）、`_baseline/`、`_verify/`、`_inbox/`；多副本时**以 `src/docs/` 版本号最大者为真相源**。
- ✅ 新会话交接走**正文粘贴优先**（本环境不接收 zip，见规范 13.5）。
- ❌ 禁止在仓库根散落补丁 / 临时文件 / 截图。
- ❌ 禁止在 `src/` 之外新增业务代码。
- ❌ 禁止把「只存在云端、未交付」的东西当成已完成。
- ❌ 禁止把 zip / 压缩包作为**交接载体**。

### 11.2 必须（总清单）

1. **动代码前先完整阅读 `src/docs/` 下 3 份规范文档**。
2. 保持既有 UI 实现**不回退**（三栏仿微信、首页隐藏第二列、设置在最底、自定义标题栏、明暗主题）。
3. 技术栈版本**锁定**，不擅自升级 / 降级。
4. 交付前 **Debug + Release 均 0 Error / 0 Warning**。
5. 交付 **git 补丁 + 变更清单 + 可点击下载链接**。
6. 用户提供的参考源码**以其原件为准**，不改写核心逻辑。
7. **规范与代码同步更新**。
8. 复杂功能**先给可运行的最小实现**，再逐步扩展。
9. 框架层（`Shared` / `Core` / `Shell`）稳定后**默认冻结**，新功能只在 `Module.*` 内；改动框架层须先经用户明确同意。
10. 交接材料要求**最小化**（3 份文档正文 + 基线声明 + 目标文件），**不要求整仓、不要求 zip**。
11. 链接失效时**必有二级兜底**（先单独重发；仍不行则把补丁正文分片贴出）。
12. 交付件文件名遵循 **`p<NN>-<slug>.patch`**（短、纯 ASCII、可手打；见 10.2 规则 5）。

### 11.3 禁止（总清单）

1. **禁止引入任何第三方 UI 库**。
2. **禁止臆造**用户未要求的功能。
3. **禁止删除 / 回退**用户已确认的实现与文档。
4. **禁止在 ViewModel 构造函数里触发导航**。
5. **禁止**让 ViewLocator / 视图解析**返回 null** 导致崩溃。
6. **禁止**模块引用 `Shell` 或模块之间互相引用。
7. **禁止**在 `csproj` 中写包 `Version`。
8. **禁止**使用 `.xaml` 扩展名、以及 WPF 专有 XAML 写法。
9. **禁止**只改代码不改规范（或反之）。
10. **禁止**交付没有下载链接的补丁。
11. **禁止**无正当理由改动框架层（`Shared` / `Core` / `Shell`）。
12. **禁止**照搬 WPF 版工程的目录结构与命名（**功能可参考，结构与命名以本规范为准**）。
13. **禁止**在交付件**尚未落盘**时声明"已生成 / 已就绪"。
14. **禁止**把 `<fileDownload>` 标签与文字 / 代码块**写成同一行**，或**只用文件名冒充链接**。
15. **禁止**交付件文件名含**全角括号 / 中文标点 / 空格**。
16. **禁止**在未通过交付自检清单（`NewToys-AI协作提示词.md` 附录 A）的情况下收尾交付。
17. **禁止**要求用户**上传 zip / 压缩包**作为交接方式（本环境不接收）。
18. **禁止**在用户反馈"没有链接"后仍只重复"见上方链接"，不走二级兜底通道。
19. **禁止**使用带**日期长前缀 / 中文标点 / 括号**的补丁文件名（如 `NewToys-src-20261009-01-中文（括号）.patch`）。

---

## 12. 经验教训

> 本节记录项目推进过程中的真实踩坑与结论，**用于避免重复犯错**；新增教训持续追加。

### 12.1 平台与语法

1. **Avalonia ≠ WPF，写法不能照搬**：
   - XAML 扩展名必须是 `.axaml`（Avalonia 12 不认 `.xaml`）；
   - `xmlns` 必须全部声明在根元素，内嵌模板里不能再声明；
   - 无 `ItemContainerStyle`；用 `<Style Selector="...">` 替代 WPF 的 `<Style TargetType="...">`；无 `Border.HorizontalContentAlignment`；行 / 列定义用字符串 `"Auto,*,Auto"`，没有 `<Auto/>` 短标签。
2. **Avalonia 12 默认预编译 XAML**：**不能**用「独立 `.axaml` 资源字典 + `AvaloniaXamlLoader.Load(uri)`」加载主题，会抛 `No precompiled XAML found`。主题改为**纯代码构建 `ResourceDictionary`** 注入。

### 12.2 工程与构建

3. **中央包管理（CPM）下 `NU1010`**：`csproj` 出现 `<PackageReference Include="X" />`，`Directory.Packages.props` 就**必须**有对应 `<PackageVersion Include="X" />`；`csproj` 里**不得**写 `Version`。
4. **`CS0260` 缺 `partial`**：凡带 `[ObservableProperty]` / `[RelayCommand]` 的类必须 `partial`（源生成器需要另一半分部声明）。
5. **产物命名要与脚本一致**：`Shell` 必须显式 `AssemblyName=NewToys`，否则脚本找不到 `NewToys.exe`。
6. **`Directory.Packages.props` 只能有一份**：根目录与 `src/` 各放一份会冲突、改了不生效。

### 12.3 架构与加载

7. **模块禁止引用 Shell**：曾把公共基类放进 `Shell`，导致模块反向依赖 Shell（循环依赖）。**公共基类一律放 `Shared`**。
8. **Debug 下模块是延迟加载的**：仅靠 `AppDomain.GetAssemblies()` 扫描会**一个模块都扫不到**，表现为「左侧菜单为空」。Debug 必须用**显式类型清单**。
9. **模块被重复注册**：会导致菜单**成倍重复**。`ModuleLoader` 要用**同一实例**注册 `IModule`，避免 `Initialize` 被调两次。
10. **菜单分组顺序会漂移**：只按加载顺序排，每次运行可能不同。分组必须显式给 `Order`。
11. **模块 DLL 必须与 `NewToys.exe` 同级**：运行时按 `Assembly.GetExecutingAssembly().Location` 定位，不要依赖工作目录。

### 12.4 导航与启动

12. **不要在 ViewModel 构造函数里导航**：此时菜单尚未注册完，找不到目标 → **启动闪退**（且编译不报错）。首次导航必须由 `App` 在模块初始化之后触发。
13. **视图解析绝不能返回 null**：`ContentControl` 绑定 null 会崩。找不到视图要返回**兜底控件**。
14. **菜单点击无反应**：只做 `SelectedItem` 双向绑定、却没监听变更去调导航，会出现"点了不动、从别处触发才更新"。要么给 `OnXxxChanged` 钩子写回导航服务，要么直接绑命令；并用 `_isSyncing` 标志位**防双向绑定死循环**。

### 12.5 协作与交付

- **交接方式想当然**：早期把"上传 zip 快照"写进交接协议，而本环境**不接收压缩包**，协议根本不可执行 → 交接要求必须**基于实测通道**（**正文粘贴优先**），并明确"禁用 zip"。
- **交付只留单通道**：只给下载链接、没有兜底，链接一旦在用户端渲染失败就"失联" → 必须设**二级通道**（单独重发 → 贴补丁正文），保证最坏情况下也能拿到。

15. **交付必须给可点击下载链接**（本项目**头号反复事故**）：曾多次出现"补丁已就绪"却拿不到链接。**根治办法见第 10 章**，要点：
    - **先落盘再声明**——文件必须真实写入并用命令确认存在，禁止"文字有、磁盘无"；
    - **标签独立成行**——`<fileDownload>绝对路径</fileDownload>` 独占一行、前后留空行，禁止与文字/代码块同行；
    - **禁止文件名冒充链接**——正文只写"见上方链接"；
    - **交付件文件名用纯 ASCII**——禁止全角括号 / 中文标点（如 `xxx（基线）.patch` 易被截断）；
    - **收尾前过自检清单**——七项门禁任一不过就不发。
16. **补丁基线必须与用户本地一致**：基于错误基线出补丁会导致 `git apply` 失败。出补丁前确认用户当前已应用哪些补丁；失败时按其**真实基线**重新出，不要盲目 `--3way`。
17. **一次只改一个问题、逐个 `git apply` 验证**：便于定位问题、便于回滚。
18. **只改用户允许的范围**：用户明确「只改 doc」时就只动 `src/docs/`，不夹带代码改动。
19. **不要照搬参考工程的结构**：WPF 版只提供**功能参考**，Avalonia 版的结构与命名**以本项目规范为准**（见 4.4 / 4.5）。
20. **框架层要冻结**：反复重构 `Shell` / `Core` / `Shared` 会牵连全部模块、甚至"回到几个版本前"。框架稳定后只演进 `Module.*`（见 4.1.1）。
21. **同一文件的多处改动必须串行执行**：本轮曾因对同一文件**并发写入**，导致其中一处改动被另一处覆盖丢失（版本号没更新、章节没生效）。教训：**改同一个文件的多段内容时，一次只改一处、改完确认再改下一处**；生成补丁前务必**逐条核对标记文本是否都在**。
22. **文档交付前要自校验**：出补丁前用命令逐项 grep 关键标记（版本号、章节标题、清单条目），确认**所有预期改动真实落盘**，而不是"以为改了"。
23. **补丁必须核对「文件清单」**：只发文档、**漏掉新增的脚本 / 资源**＝交付失败（本项目真实发生过：号称交付三个脚本的补丁里，一个脚本都没有）。出补丁后必须用 `git diff --stat` 列出文件清单，与承诺**逐条对照**。
24. **可执行产物交付前必须真跑一遍**：本轮三个脚本首版存在「导出写 3 个反引号、导入按 6 个匹配」的**致命不一致**——不真实运行根本发现不了。凡脚本 / 程序 / 网页，交付前必须在本环境跑通，并做**往返（导出→导入）或端到端**验证；只"看代码觉得对"不算验证。

---

## 13. 工程结构与运行环境约束

> 本节约束「东西放在哪里」。目的：让**任何一个新会话（人或 AI）在 30 秒内定位到真相源**，不再被多副本、散落文件带偏。

### 13.1 真相源原则（Single Source of Truth）

1. **唯一真相源 = 用户本地 git 仓库**。代码、文档、补丁的最终归属都在这里；本地 `git log` 就是完整可追溯的基线链。
2. **云端沙箱只是临时工作台，随时可能被重置**（本项目已真实发生过源码被清空）。因此：
   - 云端**不承担存储职责**，只负责「读基线 → 改 → 编译 → 出补丁」；
   - 任何成果必须**以 git 补丁形式回到用户本地**，否则等于没做；
   - 禁止把「只存在云端、未交付」的东西当成已完成。
3. **流转载体只有两类**：① 由用户提供的基线材料（**正文粘贴 / 单文件上传**，见 13.5）；② AI 产出的 `git apply` 补丁。**不依赖"我记得上次改了什么"**。
   > ⚠️ 本环境**不接收 zip / 压缩包**（实测不可用）。**禁止把"上传 zip"写进任何交接要求**。

### 13.2 仓库目录结构（固定，不得随意外扩）

| 路径 | 归属 | 入 git | 说明 |
|---|---|---|---|
| `src/` | 源码真相源 | ✅ | 唯一源码目录；7 个项目 + `Directory.*.props` + `NewToys.slnx` |
| `src/docs/` | 文档 | ✅ | **3 份**规范文档（"宪法"），**不得删除 / 移动 / 改名** |
| `scripts/` | 构建脚本 | ✅ | `build / run / clean / publish`；**由用户维护，AI 默认不改** |
| 根目录散文件 | 仓库元文件 | ✅ | 仅允许 `.gitignore` / `global.json` / `README*.md` |
| `artifacts/` | 编译中间产物 | ❌ | `bin/` `obj/`，脚本生成 |
| `Modules/` | 模块 DLL（Release 加载源） | ❌ | 与 `NewToys.exe` 同级；脚本自动同步 |
| `var/` | 运行数据 | ❌ | `config/ logs/ cache/ temp/`；`config/` 存主题等 |
| `production/` | 发布产物 | ❌ | `publish.ps1` 输出 |
| `patches/` | 交付补丁归档 | 建议 ✅ | 存放历次 `*.patch`，便于回溯 |

### 13.3 目录与命名硬约束

- ✅ 新增**顶层目录**必须先在规范登记（更新本表）后才允许出现。
- ✅ 生成物目录（`artifacts/` `Modules/` `var/` `production/`）**禁止手工放源码**，且一律进 `.gitignore`。
- ✅ 源码只放 `src/` 下，并遵守第 4 章的模块内部结构（**按需创建，不用不建**）。
- ✅ 交付件文件名**纯 ASCII**（见第 10 章）。
- ❌ 禁止在仓库根散落补丁 / 临时文件 / 截图（应放 `patches/`，或加入忽略）。
- ❌ 禁止把 zip / 压缩包作为**交接载体**（用户→AI 方向；本环境不接收压缩包，见 13.5.1）。
- ❌ 禁止把整个仓库打成 zip 交给用户做常规更新（AI→用户 方向；用户明确要求除外）。
- ❌ 禁止在 `src/` 之外新增业务代码。
- ❌ 禁止交付「漏掉新增文件」的补丁：出补丁后必须列出文件清单并与承诺逐条核对（尤其新增的脚本 / 资源）。

### 13.4 云端工作台结构约束（AI 侧）

沙箱工作区**根目录固定使用下列角色目录**，禁止散落文件：

| 角色目录 | 用途 | 生命周期 |
|---|---|---|
| `NewToys/` | **唯一工程工作区**（对应仓库根） | 会话内 |
| `patches/` | 每次产出的补丁归档 | 产出后交付 |
| `_baseline/` | 干净基线快照（只读对照） | 用完即弃 |
| `_verify/` | `git apply --check` 验证副本 | 用完即删 |
| `_inbox/` | 用户上传的截图 / 源码 / 报错素材 | 只读 |

> 若工作区已存在**多份工程副本**，先确认哪份含最新文档（**以 `src/docs/` 版本号最大者为真相源**），其余一律标注为 baseline / verify 用途，避免「改错目录」。

**上传落点实测**：平台会把用户上传的**图片**落到工作区的**数字命名子目录**（如 `…/15835723203967525676/xxx.png`）；**压缩包不会落地**。因此 `_inbox/` 只用于图片类素材，**文本类基线一律走正文粘贴**（见 13.5）。

### 13.5 新会话交接协议（**免 zip**，6 步进状态）

> 前提：本环境**不能接收 zip / 压缩包**（实测：上传只会落地单文件，压缩包不落地）。
> 交接一律按下方「可用通道」进行，**不得再要求用户上传压缩包**。

#### 13.5.1 可用通道（按可靠性排序）

| 通道 | 可用性 | 说明 |
|---|---|---|
| **正文粘贴** | ✅ **首选，零依赖** | 直接把文档 / 源码文本贴进消息；适用于任意数量、任意类型 |
| **单文件上传** | ✅ 可用 | 图片已验证；文本 / 代码文件以平台实际为准 |
| 多文件 / 文件夹上传 | ⚠️ 不作为依赖 | 若可行则更快；**不得作为唯一手段** |
| **zip / 压缩包** | ❌ **不可用** | 本环境不接收压缩包；**禁止写入交接要求** |

#### 13.5.2 交接最小包（按需提供，**不必全量**）

1. **必读文档**：`src/docs/` 下 **3 份**规范的正文（**粘贴正文**或单文件上传）。
2. **基线声明**：一句话——"已应用到**补丁 N**"（对照《项目现状与进度》「当前基线」节）。
3. **目标文件**：本次要改动的源文件正文（通常 **1–5 个**，**只给这几个即可**）。

> 不必上传整个 `src/`。**补丁是增量**，AI 只需"**文档（规则）+ 基线（位置）+ 目标文件（内容）**"三样即可产出正确补丁。

#### 13.5.3 6 步进状态

1. **取料**：用户**粘贴** 3 份文档正文（或单文件上传），并声明当前基线；**不要求**上传 zip / 整仓。
2. **定位真相源**：以《项目现状与进度》的「当前基线」节为准，核对版本。
3. **读宪法**：按序读 3 份文档（规范 → 现状 → AI 协作提示词）。
4. **确认基线**：明确"已应用哪些补丁"，作为出补丁的 diff 基线。
5. **小步交付**：一次一个问题 → 改 → 编译 → 出补丁 → 用户 `git apply`。
6. **回写台账**：每次交付后同步更新《项目现状》的 **基线 / 已完成 / 待办** 三节。

> **兜底**：若连单文件上传也不可用，则**全部走正文粘贴**——文档与源码都是纯文本，粘贴即等效。

### 13.6 结构自检

- ☐ 源码是否**只在** `src/`？
- ☐ 生成物是否**都在**忽略目录？
- ☐ `src/docs/` **3 份**是否完整？
- ☐ 交付件是否已归档到 `patches/`、**文件名纯 ASCII**？
- ☐ 台账（`NewToys-项目现状与进度.md`）是否已**回写**？
- ☐ 交接要求里**没有出现**"上传 zip / 压缩包"字样？
- ☐ 需要用户提供的材料是否**已最小化**（文档正文 + 基线声明 + 目标文件），而非整仓？

---

## 14. 源码快照导出/导入（v1.9 新增）

为适配 AI 协作场景下的"新会话续作"需求（本环境不支持 zip 上传、正文粘贴零散文件容易乱），项目内置 3 个脚本，用于把源码导出为**单个 markdown 文件**上传给 AI，以及把 AI 返回的 markdown **反向还原为源码**。

> 这套机制**完全替代"上传 zip 整包"**；是新会话续作的标准方式。

### 14.1 三个脚本

| 脚本 | 作用 | 输出位置 |
|---|---|---|
| `scripts/export-framework.ps1` | 导出框架层（Shared + Core + Shell + 根目录配置）为单文件 md | `sources/framework.md` |
| `scripts/export-module.ps1 <模块名>` | 导出单个业务模块（如 `PcTools`/`Settings`）为单文件 md | `sources/module-<name>.md` |
| `scripts/import-sources.ps1 <输入md>` | 解析 md 中的 `FILE:` 段，反向写入 `src/`；自动备份被覆盖文件 | 直接写 `src/`，备份到 `.sources-import-backup/<时间戳>/` |

### 14.2 导出文件格式约定（机器可解析）

每个导出的 md 由若干段组成，每段格式如下：

```markdown
#### FILE: <相对 src/ 的路径，用 / 分隔，不带 src/ 前缀>

``````语言标识
文件完整内容（UTF-8，保留换行与缩进）
``````
```

- 文件头：`FILE: <relpath>`（标题级别 1–6 均可识别；路径用反引号包裹或纯文本都能解析）
- 代码块使用 **6 个反引号** 包裹（``````），避免与文件内容里普通的 ``` 冲突；**import 同时兼容 3 个及以上的围栏**，以与"开启行"等长的那行作为结束标记
- 语言标识：`.cs` → `csharp`，`.axaml/.xaml/.csproj/.props/.slnx` → `xml`，`.json` → `json`，`.md` → `markdown`，其他 → `text`
- 若某段代码块语言为 `delete`，则 import 时**删除该文件**（用于 AI 返回"请删除 xx 文件"的场景）

### 14.3 导出/导入安全规则（硬约束）

1. **import 必须做路径穿越校验**：
   - 禁止 `../`、绝对路径、盘符开头路径；
   - 目标路径经 `Path.GetFullPath` 后必须落在 `src/` 下，否则直接 SKIP；
   - **额外容错**：import 会自动去掉路径开头的 `./` 与 `src/`（导出格式是相对 `src/` 的路径）。
2. **import 必须自动备份**：默认备份到 `.sources-import-backup/<timestamp>/`，可指定 `-BackupDir`。
3. **import 提供 `-DryRun`**：只预览新增/修改/删除统计，不实际写文件，便于用户先确认。
4. **export 排除产物**：`bin/ obj/ publish/` 目录、`*.dll *.exe *.pdb *.cache *.user *.generated.cs` 等均不导出。
5. **export 输出位置固定在 `sources/`**：该目录写入 `.gitignore`，不入版本库（是协作临时产物）。
6. **导出范围**：`export-framework.ps1` 导出 **Shared + Core + Shell 三个项目源码 + 根目录配置**（`NewToys.slnx`、`Directory.Build.props`、`Directory.Packages.props`、`.gitignore`、`global.json`）；`src/docs/` 文档**默认不在导出范围内**；`export-module.ps1` 只导出 `src/Module.<Name>/`。
7. **import 保留原有换行风格**：目标文件原为 CRLF 就写回 CRLF，否则 LF；新文件默认 LF。
8. **import 统一收尾**：文件尾保证**恰好一个换行**，编码 **UTF-8 无 BOM**（避免整仓 diff 噪音）。

> 如需把 `src/docs/` 也纳入导出，扩展 `export-framework.ps1` 的 `$FrameworkDirs` 数组即可（当前默认只导出代码与根配置）。

### 14.4 新会话续作标准流程（v1.9 起，替换旧流程）

```
[用户本地]
  ① pwsh ./scripts/export-framework.ps1
     → 生成 sources/framework.md
  ② 如果本次只改某模块，再执行：
     pwsh ./scripts/export-module.ps1 PcTools
     → 生成 sources/module-pctools.md

[新会话中]
  ③ 开场白：把 src/docs/NewToys-AI协作提示词.md 的正文贴给 AI
  ④ 上传 framework.md（新会话首次）+ 本次要改的 module-xxx.md
  ⑤ 提需求（或贴 WPF 参考源码）

[AI 修改后交付]
  ⑥ AI 返回一个（或多个）sources md，格式遵循 14.2
  ⑦ 用户保存为 sources/xxx.md，执行：
     pwsh ./scripts/import-sources.ps1 sources/xxx.md -DryRun   # 预览
     pwsh ./scripts/import-sources.ps1 sources/xxx.md            # 实际写入
  ⑧ pwsh ./scripts/run.ps1 编译验证
  ⑨ git add && git commit（备份目录 .sources-import-backup/ 已在 gitignore 中）
```

### 14.5 为什么这个方案比 zip / 贴零散文件好

| 方式 | 优点 | 缺点 |
|---|---|---|
| zip 整包 | 全量 | ❌ 本环境不支持上传 zip |
| 零散贴文件 | 直观 | 容易漏、路径错乱、AI 拼不回 |
| **单 md 快照（本方案）** | ✅ 单文件可上传 ✅ 机器可解析可反向还原 ✅ 带元信息（时间/模块名）✅ 支持分模块按需发送 ✅ 天然兼容 -DryRun 预览与自动备份 | 需要多执行一条导出命令（脚本一条命令搞定） |

### 14.6 协作时 AI 返回 md 的硬性要求

AI 在本机制下交付源码时，必须遵守：

1. **返回文件必须是完整的 markdown**，包含文件头元信息表格 + 每段 `FILE:` 段；
2. **不要返回 git patch**：用户可能新会话、无 git 历史、或 git apply 出问题时，用 sources md 更通用（patch 是 diff，sources md 是快照，互补使用）；
3. **每段必须含完整文件内容**（不返回 diff 片段），便于 `import-sources.ps1` 直接覆盖；
4. **删除文件**时用 `DELETE` 语言块：
   ```
   #### FILE: <相对 src/ 的路径>
   `````delete
   （此文件已删除）
   `````
   ```
5. **路径必须相对 `src/`**、用 `/` 分隔，且**不带 `src/` 前缀**；禁止 `..`、盘符、绝对路径；
6. 交付后必须在回复里给出 md 文件的下载链接（按规范第 10 章交付规则），不能只在正文写代码块让用户另存（但代码块作为兜底通道仍需提供——若下载链接失效，用户可复制代码块保存为 md 再 import）。

---

## 15. 标准工作流（日常闭环）

> 本章是**日常协作的唯一权威流程**。一句话：**框架稳定 + 文档约束 + 模块化源码快照上传 + 小步补丁落地**。

### 15.1 总体闭环（单次迭代）

```
① 本地导出快照  →  ② 新会话提需求  →  ③ AI 改并按规范交付  →  ④ 本地落地+编译+提交  →  ⑤ 回写台账
 (PowerShell)       (粘贴 + 上传 md)    (patch / sources md + 链接)   (git apply / import)     (AI 更新《现状》)
```

### 15.2 分步操作

**① 本地导出快照**（每次新会话首次）
```powershell
pwsh ./scripts/export-framework.ps1            # → sources/framework.md（首次必做）
pwsh ./scripts/export-module.ps1 PcTools       # → sources/module-pctools.md（只改某模块时）
```

**② 新会话提需求**
- 粘贴 `src/docs/NewToys-AI协作提示词.md` 的「提示词正文」；
- 上传 `sources/framework.md`（首次）+ 本次要改的 `sources/module-xxx.md`；
- 声明当前基线（"已应用到**补丁 N**"）并写需求。

**③ AI 交付**：先读 3 份文档 → 摸底 → 改 `src/` → **Debug/Release 均 0/0** → 落盘交付件 → 给**下载链接 + 变更清单 + 应用步骤 + 验证记录**。交付形态见 15.3。

**④ 本地落地 + 编译 + 提交**
```bash
# 若交付的是 git patch
git apply --check "p16-xxx.patch"
git apply "p16-xxx.patch"
# 若交付的是 sources md
pwsh ./scripts/import-sources.ps1 sources/xxx.md -DryRun
pwsh ./scripts/import-sources.ps1 sources/xxx.md
# 公共收尾
pwsh ./scripts/run.ps1
git add -A && git commit -m "<type>: <简述>"
```

**⑤ 回写台账**：AI 随补丁更新《项目现状与进度》的 **基线 / 已完成 / 待办** 三节。

### 15.3 交付形态怎么选

| 场景 | 推荐形态 |
|---|---|
| 小改动 / 精确 diff / 需要 `--check` 自检 | **git patch**（默认，命名 `p<NN>-<slug>.patch`） |
| 新增或整体重写多个文件 / 本地 `git apply` 失败 | **sources md 快照**（`import-sources.ps1` 还原） |
| 用户明确指定 | 以用户为准 |

> 两者**互补**：patch 是"差量"，sources md 是"快照"。默认 patch，出问题切 md。

### 15.4 为什么要这么设计

- **模块化上传**：只传"要改的模块 + 框架快照"，不必整仓，快、省、稳；
- **小步补丁**：一次一个主题，逐个 `git apply`，好定位、好回滚；
- **文档约束**：AI 按同一套规范"读 → 改 → 自检"，避免臆造与回退；
- **真相源在本地**：云端只是工作台，成果一律以补丁回到本地 git。

---

## 附录 A. 常见坑对照表

| 现象 | 根因 | 解法 |
|---|---|---|
| `NU1010` 未定义 PackageVersion | 中央包管理下 `csproj` 直接引用但 props 未声明 | 在 `Directory.Packages.props` 补 `<PackageVersion>`；`csproj` 不写版本 |
| `CS0260` 缺少 partial | 带 `[ObservableProperty]` 的类没写 `partial` | 类声明加 `partial` |
| 启动闪退 `No precompiled XAML found` | 用 `AvaloniaXamlLoader.Load` 加载独立资源字典 axaml | 主题改纯代码构建 `ResourceDictionary` 注入 |
| XAML 报 `AVLN2000` | 用了 WPF 专有写法 | 改 Avalonia 语法（Selector 替代 TargetType 等） |
| 模块 XAML 不编译 | 用了 `.xaml` 扩展名 | 改 `.axaml` |
| `xmlns` 报错 | 在内嵌模板里声明 xmlns | 全部 xmlns 移到根元素 |
| Debug 下菜单为空 | 程序集延迟加载，扫描不到 | 改用显式类型清单 |
| 启动落在错误页 / 闪退 | 构造函数里导航（菜单未就绪） | 首次导航移到 App 第 7 步 |
| 菜单点击无反应 | 只双向绑定了属性，未监听变更触发导航 | 加 `OnXxxChanged` 钩子 + `_isSyncing` 防死循环 |
| 菜单分组顺序漂移 | 依赖程序集加载顺序 | 分组显式设 `Order` |
| 模块 DLL 找不到 | 未同步到 exe 同级 `Modules/` | 用 `build.ps1` 自动同步；运行时按 exe 位置定位 |
| 侧栏菜单重复 N 次 | 模块被重复注册 | `ModuleLoader` 用同一实例注册 `IModule`，避免二次注册 |
| 模块页启动崩溃 `XamlLoadException` | 页面 VM 未实现，导航解析失败 | 解析失败回退占位页；先注册菜单、后补页面 |
| 补丁 `git apply` 失败 | 补丁基线与用户本地不一致 | 基于真实基线重出补丁，勿盲目 `--3way` |
| 布局"回到几个版本前" | 反复重构框架层 | 框架冻结，只演进 `Module.*` |
| **用户说"没有链接/看不到链接"** | ①文件未真实落盘；②标签与文字同行被吞；③只用文件名冒充链接；④文件名含全角括号被截断 | 按第 10 章规则 1–5：**先落盘验证 → 标签独立成行 → 正文不写文件名冒充 → 文件名纯 ASCII**；收尾过自检清单 |
| 补丁名太长、手打困难 | 旧命名带日期长前缀 | v1.11 起统一 `p<NN>-<slug>.patch`（见 10.2 规则 5） |
