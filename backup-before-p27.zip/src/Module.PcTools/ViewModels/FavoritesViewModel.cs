using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.PcTools.ViewModels;

/// <summary>
/// 收藏夹 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class FavoritesViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "收藏夹";
    [ObservableProperty] private string _pageIcon = "⭐";
    [ObservableProperty] private string _pageDescription = "收藏的常用文件、文件夹与程序，一键打开。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
