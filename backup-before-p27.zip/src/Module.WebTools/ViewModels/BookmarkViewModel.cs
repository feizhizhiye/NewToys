using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.WebTools.ViewModels;

/// <summary>
/// 书签管理 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class BookmarkViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "书签管理";
    [ObservableProperty] private string _pageIcon = "🔗";
    [ObservableProperty] private string _pageDescription = "批量书签可用性检测、去重、导入导出。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
