using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using NewToys.Core.Services;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;

namespace NewToys.Module.Settings.ViewModels;

public partial class ConfigFileItem : ObservableObject
{
    [ObservableProperty] private string _name = "";
    [ObservableProperty] private long _sizeBytes;
    [ObservableProperty] private string _lastWriteTime = "";
}

public partial class DataViewModel : ObservableObject
{
    private readonly ConfigStoreService _configStore;

    [ObservableProperty] private string _configDir = "";
    [ObservableProperty] private string _statusText = "就绪";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string? _lastBackupPath;
    [ObservableProperty] private string? _lastImportInfo;

    public ObservableCollection<ConfigFileItem> ConfigFiles { get; } = new();

    public DataViewModel(ConfigStoreService configStore)
    {
        _configStore = configStore;
        ConfigDir = configStore.ConfigDir;
        Refresh();
    }

    [RelayCommand]
    private void Refresh()
    {
        ConfigFiles.Clear();
        foreach (var f in _configStore.ListConfigFiles().OrderBy(x => x.Name))
        {
            ConfigFiles.Add(new ConfigFileItem
            {
                Name = f.Name,
                SizeBytes = f.SizeBytes,
                LastWriteTime = f.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"),
            });
        }
        StatusText = $"共 {ConfigFiles.Count} 个配置文件";
    }

    /// <summary>
    /// 备份配置：View 通过事件/直接读取 BackupText 拿到 JSON 字符串并另存。
    /// 这里只做打包，文件保存对话框由 View 侧触发（ViewModel 不直接依赖 UI）。
    /// </summary>
    public string BuildBackupText()
    {
        return _configStore.ExportBackup();
    }

    /// <summary>View 调用：让 VM 标记"用户已保存到 path"，用于状态栏提示。</summary>
    public void MarkBackupSaved(string path)
    {
        LastBackupPath = path;
        StatusText = "备份已保存：" + path;
    }

    /// <summary>
    /// 预览备份文件内容，返回包含的文件列表。
    /// </summary>
    public (bool Ok, string[] Files, string Error) PeekBackupFile(string filePath)
    {
        try
        {
            var text = File.ReadAllText(filePath);
            return _configStore.PeekBackup(text);
        }
        catch (System.Exception ex)
        {
            return (false, System.Array.Empty<string>(), "读取失败：" + ex.Message);
        }
    }

    /// <summary>
    /// 执行导入：覆盖前自动备份当前配置到 .bak-时间戳 目录。
    /// </summary>
    public (bool Ok, string[] Imported, string AutoBackupDir, string Error) ImportBackupFile(string filePath)
    {
        try
        {
            var text = File.ReadAllText(filePath);
            var r = _configStore.ImportBackup(text);
            if (r.Ok)
            {
                LastImportInfo = $"已导入 {r.ImportedFiles.Length} 个配置，自动备份于：{r.AutoBackupDir}";
                StatusText = LastImportInfo;
                Refresh();
            }
            else
            {
                StatusText = "导入失败：" + r.Error;
            }
            return r;
        }
        catch (System.Exception ex)
        {
            StatusText = "导入失败：" + ex.Message;
            return (false, System.Array.Empty<string>(), "", ex.Message);
        }
    }
}
