using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.WebTools.ViewModels;

/// <summary>
/// 网页抓取 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class ScrapeViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "网页抓取";
    [ObservableProperty] private string _pageIcon = "🕷";
    [ObservableProperty] private string _pageDescription = "抓取网页正文、图片、链接等资源。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
