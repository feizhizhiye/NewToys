using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using NewToys.Shared.Services;

namespace NewToys.Module.Settings.ViewModels;

public partial class ThemeViewModel : ObservableObject
{
    private readonly IThemeService _themeService;

    [ObservableProperty]
    private bool _isDarkMode;

    public ThemeViewModel(IThemeService themeService)
    {
        _themeService = themeService;
        _isDarkMode = themeService.Current == AppTheme.Dark;
        _themeService.ThemeChanged += (_, t) =>
        {
            IsDarkMode = t == AppTheme.Dark;
        };
    }

    partial void OnIsDarkModeChanged(bool value)
    {
        var target = value ? AppTheme.Dark : AppTheme.Light;
        if (_themeService.Current != target)
        {
            _themeService.SetTheme(target);
        }
    }

    [RelayCommand]
    private void ToggleTheme()
    {
        _themeService.Toggle();
    }
}
