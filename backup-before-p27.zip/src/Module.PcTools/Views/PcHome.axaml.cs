using Avalonia.Controls;

namespace NewToys.Module.PcTools.Views;

public partial class PcHome : UserControl
{
    public PcHome()
    {
        InitializeComponent();
    }
}
