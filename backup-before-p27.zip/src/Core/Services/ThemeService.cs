using NewToys.Shared.Services;
using System;
using System.IO;
using System.Text.Json;

namespace NewToys.Core.Services;

public class ThemeService : IThemeService
{
    private readonly ConfigStoreService _configStore;
    private readonly string _configPath;
    private AppTheme _current;

    public AppTheme Current => _current;

    public event EventHandler<AppTheme>? ThemeChanged;

    public ThemeService(ConfigStoreService configStore)
    {
        // 与 ConfigStoreService 共用 var/config 目录，避免 Debug/Release 路径不一致
        _configStore = configStore;
        var baseDir = configStore.ConfigDir;
        Directory.CreateDirectory(baseDir);
        _configPath = Path.Combine(baseDir, "theme.json");

        _current = LoadTheme();
    }

    public void SetTheme(AppTheme theme)
    {
        if (_current == theme) return;
        _current = theme;
        SaveTheme(theme);
        ThemeChanged?.Invoke(this, theme);
    }

    public void Toggle()
    {
        SetTheme(_current == AppTheme.Light ? AppTheme.Dark : AppTheme.Light);
    }

    private AppTheme LoadTheme()
    {
        try
        {
            if (File.Exists(_configPath))
            {
                var json = File.ReadAllText(_configPath);
                var data = JsonSerializer.Deserialize<ThemeConfig>(json);
                if (data != null && Enum.TryParse<AppTheme>(data.Theme, out var t))
                    return t;
            }
        }
        catch { }
        return AppTheme.Light;
    }

    private void SaveTheme(AppTheme theme)
    {
        try
        {
            var data = new ThemeConfig { Theme = theme.ToString() };
            File.WriteAllText(_configPath, JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private class ThemeConfig
    {
        public string Theme { get; set; } = "Light";
    }
}
