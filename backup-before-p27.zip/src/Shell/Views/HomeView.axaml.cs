using Avalonia.Controls;

namespace NewToys.Shell.Views;

public partial class HomeView : UserControl
{
    public HomeView()
    {
        InitializeComponent();
    }
}
