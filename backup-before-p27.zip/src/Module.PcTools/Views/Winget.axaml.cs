using Avalonia.Controls;

namespace NewToys.Module.PcTools.Views;

public partial class Winget : UserControl
{
    public Winget()
    {
        InitializeComponent();
    }
}
