using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using CommunityToolkit.Mvvm.DependencyInjection;
using NewToys.Shared.Models;
using NewToys.Shared.Services;
using NewToys.Shell.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace NewToys.Shell.Views;

public partial class ShellView : Window
{
    private ShellViewModel _vm = null!;
    private INavigationService? _nav;
    private IThemeService? _theme;

    private readonly List<NavEntry> _navEntries = new();
    private bool _suppressSubMenuNav;

    /// <summary>固定停靠在侧栏最底部的设置分组 Key（对应 ShellView.axaml 里的 NavSettings 按钮）。</summary>
    private const string SettingsGroupKey = "settings";

    /// <summary>从应用资源字典取画刷，取不到则返回透明。</summary>
    private static IBrush Brush(string key)
    {
        if (Application.Current?.TryFindResource(key, out var res) == true && res is IBrush b) return b;
        return Brushes.Transparent;
    }

    private sealed class NavEntry
    {
        public string Key { get; init; } = "";
        public Button Button { get; init; } = null!;
        public Border Indicator { get; init; } = null!;
        public TextBlock Icon { get; init; } = null!;
    }

    public ShellView()
    {
        InitializeComponent();

        _vm = Ioc.Default.GetRequiredService<ShellViewModel>();
        DataContext = _vm;
        _nav = Ioc.Default.GetService<INavigationService>();
        _theme = Ioc.Default.GetService<IThemeService>();

        BuildNavButtons();
        BuildFavorites();

        _vm.PropertyChanged += OnVmPropertyChanged;
        if (_theme != null) _theme.ThemeChanged += (_, _) => ApplyThemeColors();

        TitleBar.PointerPressed += OnTitleBarPressed;
        BtnBrowser1.Click += (_, _) => Ioc.Default.GetService<HomeViewModel>()?.QuickBrowser1Command.Execute(null);
        BtnBrowser2.Click += (_, _) => Ioc.Default.GetService<HomeViewModel>()?.QuickBrowser2Command.Execute(null);
        BtnApps.Click += (_, _) => Ioc.Default.GetService<HomeViewModel>()?.QuickLaunchAppsCommand.Execute(null);
        BtnQuickSettingsBrowser1.Click += BtnQuickSettingsBrowser1_Click;
        BtnQuickSettingsBrowser2.Click += BtnQuickSettingsBrowser2_Click;
        BtnQuickSettingsApps.Click += BtnQuickSettingsApps_Click;

        ApplyThemeColors();
        ShowHomeMode();
    }

    private void BuildNavButtons()
    {
        NavList.Children.Clear();
        _navEntries.Clear();

        var menu = Ioc.Default.GetService<IMenuService>();
        if (menu == null) return;

        foreach (var g in menu.Groups)
        {
            if (g.IsHome) continue;

            // 设置分组固定复用侧栏最底部的 NavSettings 按钮：
            // 只把导航状态登记进 _navEntries，不再在 NavList 中重复生成一个入口。
            if (g.Key == SettingsGroupKey)
            {
                _navEntries.Add(new NavEntry
                {
                    Key = g.Key,
                    Button = NavSettings,
                    Indicator = SettingsIndicator,
                    Icon = SettingsIcon,
                });
                continue;
            }

            var indicator = new Border
            {
                Width = 3,
                IsVisible = false,
                VerticalAlignment = VerticalAlignment.Stretch,
                Background = Brush("AccentColor"),
            };

            var icon = new TextBlock
            {
                Text = g.Icon,
                FontSize = 20,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brush("SidebarIconInactive"),
            };

            var grid = new Grid
            {
                ColumnDefinitions = new ColumnDefinitions("3,*"),
                Children = { indicator, icon },
            };
            Grid.SetColumn(indicator, 0);
            Grid.SetColumn(icon, 1);

            var btn = new Button
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Height = 52,
                Padding = new Thickness(0),
                Background = Brushes.Transparent,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                Content = grid,
            };
            btn.Click += (_, _) => _vm.SelectGroupCommand.Execute(g);
            NavList.Children.Add(btn);

            _navEntries.Add(new NavEntry { Key = g.Key, Button = btn, Indicator = indicator, Icon = icon });
        }
    }

    /// <summary>主题切换时，重新给所有 code-behind 创建的控件上色。</summary>
    private void ApplyThemeColors()
    {
        // 侧栏图标
        foreach (var e in _navEntries)
        {
            e.Indicator.Background = Brush("AccentColor");
            e.Icon.Foreground = e.Indicator.IsVisible ? Brush("SidebarIconActive") : Brush("SidebarIconInactive");
        }
        // 标题栏按钮图标（最小化/最大化/关闭的 Path Stroke 由 axaml DynamicResource 处理，这里不需要管）
        // 收藏卡与二级菜单按钮重建
        RefreshSubMenuColors();
        RefreshFavoritesColors();
    }

    private void BuildFavorites()
    {
        FavoritesContainer.ColumnDefinitions = new ColumnDefinitions("*,*,*");
        FavoritesContainer.RowDefinitions = new RowDefinitions("Auto,Auto");
        FavoritesContainer.Children.Clear();

        var homeVm = Ioc.Default.GetService<HomeViewModel>();
        if (homeVm == null) return;

        var idx = 0;
        foreach (var fav in homeVm.Favorites)
        {
            var r = idx / 3;
            var c = idx % 3;

            var title = new TextBlock
            {
                Text = fav.Title,
                FontSize = 15,
                FontWeight = FontWeight.SemiBold,
                Foreground = Brush("TextPrimary"),
            };
            var desc = new TextBlock
            {
                Text = fav.Description,
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brush("TextSecondary"),
            };
            var stack = new StackPanel { Spacing = 6, VerticalAlignment = VerticalAlignment.Center };
            stack.Children.Add(title);
            stack.Children.Add(desc);

            var card = new Border
            {
                Background = Brush("CardBackground"),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(16),
                Cursor = new Cursor(StandardCursorType.Hand),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                MinHeight = 96,
                Margin = new Thickness(c == 0 ? 0 : 6, r == 0 ? 0 : 12, c == 2 ? 0 : 6, 0),
                DataContext = fav,
                Child = stack,
            };
            card.PointerPressed += FavCard_PointerPressed;
            // hover 效果
            card.PointerEntered += (_, _) => card.Background = Brush("HoverBackground");
            card.PointerExited += (_, _) => card.Background = Brush("CardBackground");

            Grid.SetRow(card, r);
            Grid.SetColumn(card, c);
            FavoritesContainer.Children.Add(card);
            idx++;
        }
    }

    private void RefreshFavoritesColors()
    {
        foreach (var card in FavoritesContainer.Children.OfType<Border>())
        {
            card.Background = Brush("CardBackground");
            if (card.Child is StackPanel sp)
            {
                if (sp.Children.Count > 0 && sp.Children[0] is TextBlock t1) t1.Foreground = Brush("TextPrimary");
                if (sp.Children.Count > 1 && sp.Children[1] is TextBlock t2) t2.Foreground = Brush("TextSecondary");
            }
        }
    }

    private void OnVmPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(_vm.SelectedGroup))
        {
            UpdateSelectedGroup();
            RebuildSubMenu();
        }
        if (e.PropertyName == nameof(_vm.SelectedItem))
        {
            UpdateSelectedItem();
        }
        if (e.PropertyName == nameof(_vm.IsHomePage))
        {
            if (_vm.IsHomePage) ShowHomeMode();
            else ShowPageMode();
        }
    }

    private void UpdateSelectedGroup()
    {
        foreach (var e in _navEntries)
        {
            e.Indicator.IsVisible = false;
            e.Icon.Foreground = Brush("SidebarIconInactive");
        }
        if (_vm.SelectedGroup != null)
        {
            var entry = _navEntries.FirstOrDefault(x => x.Key == _vm.SelectedGroup.Key);
            if (entry != null)
            {
                entry.Indicator.IsVisible = true;
                entry.Icon.Foreground = Brush("SidebarIconActive");
            }
        }
    }

    private void UpdateSelectedItem()
    {
        if (_vm.SelectedItem == null) return;
        PageTitle.Text = _vm.SelectedItem.Title;
        RefreshSubMenuColors();
    }

    private void RebuildSubMenu()
    {
        SubMenuList.Items.Clear();
        if (_vm.SelectedGroup == null || !_vm.SelectedGroup.Items.Any())
        {
            SubPanel.IsVisible = false;
            return;
        }

        PanelTitle.Text = _vm.SelectedGroup.Title;

        foreach (var item in _vm.SelectedGroup.Items)
        {
            var tb = new TextBlock
            {
                Text = item.Title,
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 13,
                Foreground = Brush("TextPrimary"),
            };
            var b = new Button
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Height = 44,
                Padding = new Thickness(20, 0),
                Background = Brushes.Transparent,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Tag = item.Key,
                Content = tb,
            };
            b.Click += SubMenuItem_Click;
            SubMenuList.Items.Add(b);
        }

        _suppressSubMenuNav = true;
        try
        {
            if (_vm.SelectedItem != null)
            {
                var match = SubMenuList.Items.OfType<Button>().FirstOrDefault(x => x.Tag?.ToString() == _vm.SelectedItem.Key);
                if (match != null) match.Background = Brush("SubMenuSelectedBg");
            }
        }
        finally { _suppressSubMenuNav = false; }
    }

    private void RefreshSubMenuColors()
    {
        foreach (var b in SubMenuList.Items.OfType<Button>())
        {
            if (b.Content is TextBlock tb) tb.Foreground = Brush("TextPrimary");
            var isSelected = _vm.SelectedItem != null && b.Tag?.ToString() == _vm.SelectedItem.Key;
            b.Background = isSelected ? Brush("SubMenuSelectedBg") : Brushes.Transparent;
        }
    }

    private void SubMenuItem_Click(object? sender, RoutedEventArgs e)
    {
        if (_suppressSubMenuNav) return;
        if (sender is not Button b || b.Tag is not string key) return;
        _vm.NavigateToPage(key);
    }

    private void ShowHomeMode()
    {
        SubPanel.IsVisible = false;
        Grid.SetColumn(ContentColumn, 1);
        Grid.SetColumnSpan(ContentColumn, 2);
        HomeContent.IsVisible = true;
        PageContent.IsVisible = false;
        PageHeader.IsVisible = false;
        UpdateSelectedGroup();
    }

    private void ShowPageMode()
    {
        Grid.SetColumn(ContentColumn, 2);
        Grid.SetColumnSpan(ContentColumn, 1);
        SubPanel.IsVisible = true;
        HomeContent.IsVisible = false;
        PageContent.IsVisible = true;
        PageHeader.IsVisible = true;
        RebuildSubMenu();
    }

    private void NavSettings_Click(object? sender, RoutedEventArgs e)
    {
        _vm.GoSettingsCommand.Execute(null);
    }

    private void BtnQuickSettingsBrowser1_Click(object? sender, RoutedEventArgs e)
    {
        var homeVm = Ioc.Default.GetService<HomeViewModel>();
        homeVm?.QuickSettingsBrowser1Command.Execute(null);
    }

    private void BtnQuickSettingsBrowser2_Click(object? sender, RoutedEventArgs e)
    {
        var homeVm = Ioc.Default.GetService<HomeViewModel>();
        homeVm?.QuickSettingsBrowser2Command.Execute(null);
    }

    private void BtnQuickSettingsApps_Click(object? sender, RoutedEventArgs e)
    {
        var homeVm = Ioc.Default.GetService<HomeViewModel>();
        homeVm?.QuickSettingsAppsCommand.Execute(null);
    }

    private void FavCard_PointerPressed(object? sender, PointerPressedEventArgs e)
    {
        try
        {
            if (sender is not Border b) return;
            if (b.DataContext is not HomeFavoriteItem fav) return;
            var homeVm = Ioc.Default.GetService<HomeViewModel>();
            homeVm?.FavoriteClickCommand.Execute(fav);
        }
        catch (Exception ex) { Console.WriteLine($"fav click fail: {ex.Message}"); }
    }

    private void OnTitleBarPressed(object? sender, PointerPressedEventArgs e)
    {
        if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
            BeginMoveDrag(e);
    }

    private void BtnMinimize_Click(object? sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void BtnMaximize_Click(object? sender, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    private void BtnClose_Click(object? sender, RoutedEventArgs e) => Close();
}
