using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.PcTools.ViewModels;

/// <summary>
/// 我的快捷方式 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class MyShortcutsViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "我的快捷方式";
    [ObservableProperty] private string _pageIcon = "⌨";
    [ObservableProperty] private string _pageDescription = "管理自定义快捷键、桌面快捷方式与快速启动项。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
