using CommunityToolkit.Mvvm.ComponentModel;
using NewToys.Shared.Models;

namespace NewToys.Shell.ViewModels;

public class PlaceholderViewModel : ViewModelBase
{
    public string Title { get; set; } = "";
    public string Description { get; set; } = "此页面正在开发中";
}
