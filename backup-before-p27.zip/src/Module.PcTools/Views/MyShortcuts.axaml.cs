using Avalonia.Controls;

namespace NewToys.Module.PcTools.Views;

public partial class MyShortcuts : UserControl
{
    public MyShortcuts()
    {
        InitializeComponent();
    }
}
