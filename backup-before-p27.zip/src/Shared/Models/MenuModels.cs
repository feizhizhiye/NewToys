using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace NewToys.Shared.Models;

public class MenuGroup
{
    public string Key { get; set; } = "";
    public string Title { get; set; } = "";
    public string Icon { get; set; } = "📁";
    public int Order { get; set; } = 100;
    public bool IsHome { get; set; } = false;
    public ObservableCollection<MenuItem> Items { get; set; } = new();
}

public class MenuItem
{
    public string Key { get; set; } = "";
    public string Title { get; set; } = "";
    public string Icon { get; set; } = "";
    public string ViewModelType { get; set; } = "";
}
