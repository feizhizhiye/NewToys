using System;

namespace NewToys.Shared.Services;

public interface INavigationService
{
    object? CurrentView { get; }
    string? CurrentPageKey { get; }
    string? CurrentPageTitle { get; }
    event EventHandler<string>? Navigated;
    void NavigateTo(string key);
}
