param(
    [ValidateSet("Debug", "Release")]
    [string]$Configuration = "Debug",
    [switch]$NoBuild
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptDir
$ArtifactsRoot = Join-Path $RepoRoot "artifacts\bin"
$ShellDir = Join-Path $ArtifactsRoot "Shell\$Configuration\net10.0"

if (-not $NoBuild) {
    Write-Host "==> 开始构建..." -ForegroundColor Cyan
    & (Join-Path $ScriptDir "build.ps1") -Configuration $Configuration
    if ($LASTEXITCODE -ne 0) { throw "构建失败" }
}

# 找EXE
$ShellExe = Join-Path $ShellDir "NewToys.exe"
if (-not (Test-Path $ShellExe)) {
    $ShellExe = Join-Path $ShellDir "NewToys.dll"
    if (-not (Test-Path $ShellExe)) {
        Write-Error "程序文件未找到，请先执行构建: $ShellExe"
        exit 1
    }
}

Write-Host "`n🚀 启动 NewToys ($Configuration)..." -ForegroundColor Green
Write-Host "   路径: $ShellExe`n" -ForegroundColor Gray

Push-Location $ShellDir
try {
    if ($ShellExe.EndsWith(".exe")) {
        Start-Process -FilePath $ShellExe -WorkingDirectory $ShellDir
    } else {
        dotnet $ShellExe
    }
}
finally {
    Pop-Location
}
