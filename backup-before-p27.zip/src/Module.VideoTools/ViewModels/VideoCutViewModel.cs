using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.VideoTools.ViewModels;

/// <summary>
/// 视频剪辑 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class VideoCutViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "视频剪辑";
    [ObservableProperty] private string _pageIcon = "✂";
    [ObservableProperty] private string _pageDescription = "视频片段裁剪、拼接、简单剪辑。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
