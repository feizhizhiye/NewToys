using CommunityToolkit.Mvvm.ComponentModel;
using NewToys.Core.Services;

namespace NewToys.Module.Settings.ViewModels;

public partial class PathViewModel : ObservableObject
{
    private readonly ConfigStoreService _configStore;

    [ObservableProperty] private string _browser1Path = "";
    [ObservableProperty] private string _browser2Path = "";
    [ObservableProperty] private string _defaultDownloadDir = "";
    [ObservableProperty] private string _configDir = "";

    public PathViewModel(ConfigStoreService configStore)
    {
        _configStore = configStore;
        ConfigDir = configStore.ConfigDir;
        // 浏览器路径/下载目录 真实读写后续做（需要单独的 path.json），这里先展示配置目录与占位字段
        Browser1Path = "（暂未配置）";
        Browser2Path = "（暂未配置）";
        DefaultDownloadDir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
    }
}
