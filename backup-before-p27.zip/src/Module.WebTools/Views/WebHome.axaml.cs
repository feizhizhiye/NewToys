using Avalonia.Controls;

namespace NewToys.Module.WebTools.Views;

public partial class WebHome : UserControl
{
    public WebHome()
    {
        InitializeComponent();
    }
}
