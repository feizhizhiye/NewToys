using Avalonia.Controls;

namespace NewToys.Module.Settings.Views;

public partial class PathView : UserControl
{
    public PathView() { InitializeComponent(); }
}
