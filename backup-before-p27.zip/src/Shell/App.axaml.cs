using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.Styling;
using CommunityToolkit.Mvvm.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using NewToys.Core.Services;
using NewToys.Shared.Services;
using NewToys.Shell.Services;
using NewToys.Shell.ViewModels;
using NewToys.Shell.Views;
using System;
using System.Linq;
using System.Reflection;

namespace NewToys.Shell;

public partial class App : Application
{
    private ServiceProvider? _serviceProvider;

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        try
        {
            var services = new ServiceCollection();

            services.AddSingleton<AppConfigService>();
            services.AddSingleton<ConfigStoreService>();
            services.AddSingleton<IMenuService, MenuService>();
            services.AddSingleton<IThemeService, ThemeService>();
            services.AddSingleton<INavigationService, NavigationService>();
            services.AddSingleton<ShellViewModel>();
            services.AddSingleton<HomeViewModel>();

            var moduleLoader = new ModuleLoader(services);

#if DEBUG
            var debugModuleTypes = new[]
            {
                typeof(NewToys.Module.PcTools.PcToolsModule),
                typeof(NewToys.Module.WebTools.WebToolsModule),
                typeof(NewToys.Module.VideoTools.VideoToolsModule),
                typeof(NewToys.Module.Settings.SettingsModule),
            };
            var modules = moduleLoader.LoadModules(debugModuleTypes);
#else
            var modules = moduleLoader.LoadModules();
#endif

            _serviceProvider = services.BuildServiceProvider();
            Ioc.Default.ConfigureServices(_serviceProvider);

            foreach (var module in modules)
            {
                try { module.Initialize(_serviceProvider); }
                catch (Exception ex) { Console.WriteLine($"模块初始化失败: {ex.Message}"); }
            }

            var nav = _serviceProvider.GetRequiredService<INavigationService>() as NavigationService;
            nav?.RegisterViewsFromAssembly(Assembly.GetExecutingAssembly());
            foreach (var asm in modules.Select(m => m.GetType().Assembly).Distinct())
            {
                nav?.RegisterViewsFromAssembly(asm);
            }

            var themeService = _serviceProvider.GetRequiredService<IThemeService>();
            ApplyTheme(themeService.Current);
            themeService.ThemeChanged += (_, t) => ApplyTheme(t);

            var shellVm = _serviceProvider.GetRequiredService<ShellViewModel>();
            var mainWindow = new ShellView { DataContext = shellVm };
            mainWindow.Show();
        }
        catch (Exception ex)
        {
            ShowFatalError(ex);
        }

        base.OnFrameworkInitializationCompleted();
    }

    /// <summary>
    /// 应用明暗主题。所有颜色均通过 DynamicResource 提供，控件侧不允许再出现硬编码色值。
    /// </summary>
    private void ApplyTheme(AppTheme theme)
    {
        if (Resources == null) return;

        RequestedThemeVariant = theme == AppTheme.Dark ? ThemeVariant.Dark : ThemeVariant.Light;

        var dict = new ResourceDictionary();
        void Set(string key, string color) => dict[key] = new SolidColorBrush(Color.Parse(color));

        if (theme == AppTheme.Dark)
        {
            // 全局背景与标题栏
            Set("AppBackground",            "#191919");
            Set("TitleBarBackground",       "#1F1F1F");
            Set("TitleBarText",             "#E5E5E5");
            // 标题栏按钮 hover
            Set("WindowBtnHover",           "#333333");
            Set("WindowCloseHover",         "#E81123");
            Set("WindowCloseHoverText",     "#FFFFFF");
            // 侧栏（深色主题下侧栏更深，与内容区形成层次）
            Set("SidebarBackground",        "#202020");
            Set("SidebarIconInactive",      "#9A9A9A");
            Set("SidebarIconActive",        "#FFFFFF");
            Set("SidebarActiveBg",          "#2E2E2E");
            Set("SidebarDivider",           "#2E2E2E");
            // 二级菜单面板
            Set("SidePanelBackground",      "#262626");
            Set("PanelHeaderBackground",    "#2B2B2B");
            Set("SubMenuSelectedBg",        "#2F4A38");   // 深绿选中，替代原 #D9EDDF
            Set("SubMenuSelectedText",      "#7EE0A8");
            // 内容区
            Set("ContentBackground",        "#191919");
            Set("ContentHeaderBackground",  "#1F1F1F");
            Set("StatusBarBackground",      "#1F1F1F");
            Set("CardBackground",           "#262626");
            Set("HoverBackground",          "#333333");
            Set("BorderColor",              "#333333");
            Set("TextPrimary",              "#E5E5E5");
            Set("TextSecondary",            "#9E9E9E");
            Set("MenuHover",                "#3A3A3A");
            // 强调色
            Set("AccentColor",              "#07C160");
            Set("AccentColorHover",         "#06AD56");
            Set("AccentText",               "#FFFFFF");
        }
        else
        {
            Set("AppBackground",            "#FFFFFF");
            Set("TitleBarBackground",       "#FFFFFF");
            Set("TitleBarText",             "#1F1F1F");
            Set("WindowBtnHover",           "#E5E5E5");
            Set("WindowCloseHover",         "#E81123");
            Set("WindowCloseHoverText",     "#FFFFFF");
            // 侧栏（浅色主题下侧栏用深灰，保持"深色侧栏"的视觉锚点——仿微信风格）
            Set("SidebarBackground",        "#2E2E2E");
            Set("SidebarIconInactive",      "#B7B7B7");
            Set("SidebarIconActive",        "#FFFFFF");
            Set("SidebarActiveBg",          "#444444");
            Set("SidebarDivider",           "#3F3F3F");
            // 二级菜单面板
            Set("SidePanelBackground",      "#F3F3F3");
            Set("PanelHeaderBackground",    "#F7F7F7");
            Set("SubMenuSelectedBg",        "#D9EDDF");
            Set("SubMenuSelectedText",      "#07C160");
            // 内容区
            Set("ContentBackground",        "#FFFFFF");
            Set("ContentHeaderBackground",  "#FFFFFF");
            Set("StatusBarBackground",      "#FAFBFC");
            Set("CardBackground",           "#F7F8FA");
            Set("HoverBackground",          "#EFEFEF");
            Set("BorderColor",              "#E6E8EC");
            Set("TextPrimary",              "#1F1F1F");
            Set("TextSecondary",            "#8A8A8F");
            Set("MenuHover",                "#E9E9E9");
            Set("AccentColor",              "#07C160");
            Set("AccentColorHover",         "#06AD56");
            Set("AccentText",               "#FFFFFF");
        }

        Resources.MergedDictionaries.Clear();
        Resources.MergedDictionaries.Add(dict);
    }

    private static void ShowFatalError(Exception ex)
    {
        Console.WriteLine($"启动失败: {ex}");
        try
        {
            var errWin = new Window
            {
                Width = 720, Height = 460,
                Title = "NewToys 启动失败",
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Background = new SolidColorBrush(Color.Parse("#F7F8FA")),
                Content = new ScrollViewer
                {
                    Content = new TextBlock
                    {
                        Text = ex.ToString(),
                        Margin = new Thickness(20),
                        TextWrapping = Avalonia.Media.TextWrapping.Wrap,
                        Foreground = new SolidColorBrush(Color.Parse("#1F1F1F")),
                        FontFamily = "Consolas",
                    }
                }
            };
            errWin.Show();
        }
        catch { }
    }
}
