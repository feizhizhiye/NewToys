using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.WebTools.ViewModels;

/// <summary>
/// 工具箱首页 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class WebHomeViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "工具箱首页";
    [ObservableProperty] private string _pageIcon = "🌐";
    [ObservableProperty] private string _pageDescription = "Web 工具箱概览，常用网络工具快捷入口。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
