using Avalonia.Controls;

namespace NewToys.Shell.Views;

public partial class PlaceholderView : UserControl
{
    public PlaceholderView()
    {
        InitializeComponent();
    }
}
