using Avalonia.Controls;

namespace NewToys.Module.PcTools.Views;

public partial class QuickSettings : UserControl
{
    public QuickSettings()
    {
        InitializeComponent();
    }
}
