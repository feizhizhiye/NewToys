using CommunityToolkit.Mvvm.ComponentModel;

namespace NewToys.Module.WebTools.ViewModels;

/// <summary>
/// 网络Ping 页面视图模型。当前为占位版本，仅提供基础展示数据，业务逻辑后续迭代实现。
/// </summary>
public partial class PingViewModel : ObservableObject
{
    [ObservableProperty] private string _pageTitle = "网络Ping";
    [ObservableProperty] private string _pageIcon = "📡";
    [ObservableProperty] private string _pageDescription = "Ping / Traceroute 网络连通性测试。";
    [ObservableProperty] private bool _isBusy = false;
    [ObservableProperty] private string _statusText = "就绪";
}
