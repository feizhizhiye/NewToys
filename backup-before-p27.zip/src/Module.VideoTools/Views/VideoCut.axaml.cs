using Avalonia.Controls;

namespace NewToys.Module.VideoTools.Views;

public partial class VideoCut : UserControl
{
    public VideoCut()
    {
        InitializeComponent();
    }
}
