using Avalonia.Controls;

namespace NewToys.Module.PcTools.Views;

public partial class PcInfo : UserControl
{
    public PcInfo()
    {
        InitializeComponent();
    }
}
