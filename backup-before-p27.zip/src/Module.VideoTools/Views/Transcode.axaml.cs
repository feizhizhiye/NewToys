using Avalonia.Controls;

namespace NewToys.Module.VideoTools.Views;

public partial class Transcode : UserControl
{
    public Transcode()
    {
        InitializeComponent();
    }
}
