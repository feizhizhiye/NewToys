using CommunityToolkit.Mvvm.ComponentModel;
using NewToys.Shared.Services;

namespace NewToys.Module.Settings.ViewModels;

public partial class GeneralViewModel : ObservableObject
{
    private readonly IThemeService _themeService;

    [ObservableProperty] private bool _isDarkMode;
    [ObservableProperty] private bool _showTrayIcon = true;
    [ObservableProperty] private bool _autoCheckUpdate = true;
    [ObservableProperty] private string _language = "简体中文";

    public GeneralViewModel(IThemeService themeService)
    {
        _themeService = themeService;
        _isDarkMode = themeService.Current == AppTheme.Dark;
        _themeService.ThemeChanged += (_, t) => IsDarkMode = t == AppTheme.Dark;
    }

    partial void OnIsDarkModeChanged(bool value)
    {
        var target = value ? AppTheme.Dark : AppTheme.Light;
        if (_themeService.Current != target) _themeService.SetTheme(target);
    }
}
