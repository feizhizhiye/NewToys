using Microsoft.Extensions.DependencyInjection;
using NewToys.Shared.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace NewToys.Core.Services;

public class ModuleLoader
{
    private readonly IServiceCollection _services;

    public ModuleLoader(IServiceCollection services)
    {
        _services = services;
    }

    /// <param name="debugTypes">
    /// Debug 模式下显式指定的模块类型（由 Shell 传入，例如 typeof(PcToolsModule)）。
    /// 传入是必要的：模块程序集在 Debug 下是延迟加载的，单纯扫描
    /// AppDomain.CurrentDomain.GetAssemblies() 可能一个都扫不到，导致菜单为空。
    /// 注释掉其中某一行即可跳过该模块（同时注释 Shell.csproj 对应引用）。
    /// </param>
    public List<IModule> LoadModules(Type[]? debugTypes = null)
    {
        var modules = new List<IModule>();

#if DEBUG
        // Debug模式：按显式类型清单加载（未提供时回退到扫描已加载程序集）
        modules = LoadDebugModules(debugTypes);
#else
        // Release模式：扫描exe同级Modules目录下的dll
        modules = LoadFromModulesDirectory();
#endif

        // 注册所有模块服务
        foreach (var module in modules)
        {
            try
            {
                module.RegisterServices(_services);
                _services.AddSingleton(typeof(IModule), module);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"模块注册服务失败: {ex.Message}");
            }
        }

        return modules;
    }

    private List<IModule> LoadDebugModules(Type[]? explicitTypes)
    {
        var modules = new List<IModule>();
        var moduleTypes = new List<Type>();

        if (explicitTypes is { Length: > 0 })
        {
            // 显式清单优先：同时确保对应程序集被真正加载进来
            moduleTypes.AddRange(explicitTypes.Where(t => t.IsClass && !t.IsAbstract && typeof(IModule).IsAssignableFrom(t)));
        }
        else
        {
            // 回退：自动扫描当前AppDomain所有已加载程序集找IModule实现类
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    var types = asm.GetTypes()
                        .Where(t => t.IsClass && !t.IsAbstract && typeof(IModule).IsAssignableFrom(t));
                    moduleTypes.AddRange(types);
                }
                catch { }
            }
        }

        foreach (var mt in moduleTypes)
        {
            try
            {
                if (Activator.CreateInstance(mt) is IModule m)
                    modules.Add(m);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"加载模块 {mt.Name} 失败: {ex.Message}");
            }
        }

        return modules;
    }

    private List<IModule> LoadFromModulesDirectory()
    {
        var modules = new List<IModule>();
        var baseDir = AppContext.BaseDirectory;
        var modulesDir = Path.Combine(baseDir, "Modules");
        if (!Directory.Exists(modulesDir)) return modules;

        foreach (var dll in Directory.GetFiles(modulesDir, "*.dll", SearchOption.TopDirectoryOnly))
        {
            try
            {
                var asm = Assembly.LoadFrom(dll);
                var moduleTypes = asm.GetTypes()
                    .Where(t => t.IsClass && !t.IsAbstract && typeof(IModule).IsAssignableFrom(t));
                foreach (var mt in moduleTypes)
                {
                    if (Activator.CreateInstance(mt) is IModule m)
                        modules.Add(m);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"加载插件 {Path.GetFileName(dll)} 失败: {ex.Message}");
            }
        }

        return modules;
    }
}
